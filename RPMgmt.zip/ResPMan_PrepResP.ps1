## ===================================================================
## Prepare The System For Creating Restore Points
## ===================================================================

Function For64Bit {
	$TargetPath = "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows NT\CurrentVersion\SystemRestore"
	If (-Not(Test-Path -Path $TargetPath)) {
		New-Item -Path $TargetPath -Force | Out-Null
	}
	$Res = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows NT\CurrentVersion\SystemRestore").SystemRestorePointCreationFrequency
	If (!($Res)) {
		New-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows NT\CurrentVersion\SystemRestore" -Name "SystemRestorePointCreationFrequency" -PropertyType DWORD -Value 15 | Out-Null
	}
	$TargetPath = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore"
	If (-Not(Test-Path -Path $TargetPath)) {
		New-Item -Path $TargetPath -Force | Out-Null
	}
	$Res = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore").SystemRestorePointCreationFrequency
	If (!($Res)) {
		New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore" -Name "SystemRestorePointCreationFrequency" -PropertyType DWORD -Value 15 | Out-Null
	}
}

Function For32Bit {
	$TargetPath = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore"
	If (-Not(Test-Path -Path $TargetPath)) {
		New-Item -Path $TargetPath -Force | Out-Null
	}
	$Res = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore").SystemRestorePointCreationFrequency
	If (!($Res)) {
		New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore" -Name "SystemRestorePointCreationFrequency" -PropertyType DWORD -Value 15 | Out-Null
	}
}

$CompName = $Env:ComputerName
$Check = (Get-WMIObject -NameSpace "Root\CIMV2" -Class "Win32_OperatingSystem" -ComputerName $CompName).OSArchitecture
If ($Check -IEQ "64-bit") {
	For64Bit 
}
Else {
	For32Bit
}
$Drive = (Get-WMIObject -NameSpace "Root\CIMV2" -Class "Win32_OperatingSystem" -ComputerName $CompName).SystemDrive
Enable-ComputerRestore -Drive "$Drive\"