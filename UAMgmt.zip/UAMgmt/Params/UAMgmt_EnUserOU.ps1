Param (
	[String]$OUPath,
	[String]$RepFile,
	[String]$FQDN
)
$A = Get-Date
If (Test-Path $RepFile) {
	Remove-Item $RepFile
}
Import-Module ActiveDirectory
$ErrorActionPreference = "SilentlyContinue"
$Result = (Get-ADUser -Filter {(ObjectClass -EQ "User") -AND (ObjectCategory -EQ "User")} -SearchBase $OUPath -SearchScope OneLevel | Measure-Object).Count
If ($Result -GT 0) {
	New-Item $RepFile -Type File -Force -Value "=========================== UAMGMT STATUS REPORT ENABLE ACTIVE DIRECTORY USER ACCOUNTS ==========================="
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "Task To Execute -- Enable Active Directory User Accounts In The Domain $FQDN"
	Add-Content $RepFile "Enable All User Accounts From The Selected LDAP Location -- $OUPath"
	Add-Content $RepFile "Report Created On $A"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "`n"

	$CheckNow = (Get-ADUser -LDAPFilter "(&(SAMAccountName=*)(UserAccountControl:1.2.840.113556.1.4.803:=2))" -Properties SAMAccountName, Enabled -SearchBase $OUPath -SearchScope OneLevel | Select SAMAccountName, Enabled | Measure-Object).Count
	If ($CheckNow -GT 0) {
		Get-ADUser -LDAPFilter "(&(SAMAccountName=*)(UserAccountControl:1.2.840.113556.1.4.803:=2))" -Properties * -SearchBase $OUPath -SearchScope OneLevel | Select SAMAccountName, DisplayName, UserPrincipalName | `
		ForEach-Object {
			Enable-ADAccount -Identity $_.SAMAccountName
			$UserName = $_.SAMAccountName.ToUpper()
			$FullName = $_.DisplayName.ToUpper()
			$UPN = $_.UserPrincipalName
			If ($Error) {
				Add-Content $RepFile "`n"
				Add-Content $RepFile "FAILED -- Error Occurred While Attempting To Enable AD User Account: $UserName ($UPN)"
				Add-Content $RepFile "$Error"
				$Error.Clear()
				Add-Content $RepFile "`n"			
			}
			Else {
				Add-Content $RepFile "SUCCESS -- The AD User Account $UserName ($UPN) Has Been Enabled."
				Add-Content $RepFile "Full Name -- $FullName."
				Add-Content $RepFile "`n"
			}
		}
	}
	Else {
		### All User Accounts are Already Disabled
		Add-Content $RepFile "NO ACTION PERFORMED --- $OUPath"
		Add-Content $RepFile "NO ACTION PERFORMED --- All AD User Accounts Are Already Enabled."
		Add-Content $RepFile "`n"
	}
}
Else {
	## OU Does Not Have User Accounts
	New-Item $RepFile -Type File -Force -Value "=========================== UAMGMT STATUS REPORT ENABLE ACTIVE DIRECTORY USER ACCOUNTS ==========================="
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "Task To Execute -- Enable Active Directory User Accounts In The Domain $FQDN"
	Add-Content $RepFile "Enable All User Accounts From The Selected LDAP Location -- $OUPath"
	Add-Content $RepFile "Report Created On $A"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "No Active Directory User Account Has Been Enabled."
	Add-Content $RepFile "The Input File $InputFile Contains No Data."
	Add-Content $RepFile "`n"
	Add-Content $RepFile "=================================== UAMGMT END OF STATUS REPORT ==================================="	
}
Remove-Module ActiveDirectory