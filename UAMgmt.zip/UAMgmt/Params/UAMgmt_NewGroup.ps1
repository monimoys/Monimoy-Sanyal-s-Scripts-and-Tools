Param (
	[String]$GrpPath,
	[String]$RepFile,
	[String]$InputFile
)
$A = Get-Date
If (Test-Path $RepFile) {
	Remove-Item $Repfile
}
$Result = (Import-Csv $InputFile | Where-Object {($_.GroupSAMAccountName -NE [char]32) -AND ($_.GroupSAMAccountName -NE [char]0)} | Measure-Object).Count
If ($Result -EQ 0) {
	New-Item $RepFile -Type File -Force -Value "=========================== UAMGMT STATUS REPORT CREATE NEW ACTIVE DIRECTORY GROUPS ==========================="
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "Task To Execute -- Create New Active Directory Groups"
	Add-Content $RepFile "Create Groups In Location -- $GrpPath"
	Add-Content $RepFile "Report Created On $A"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "No Active Directory GROUP Created In The Selected Location $GrpPath"
	Add-Content $RepFile "The Input File $InputFile Contains No Data."
	Add-Content $RepFile "`n"
	Add-Content $RepFile "=================================== UAMGMT END OF STATUS REPORT ==================================="
}
Else {
	$ErrorActionPreference = "SilentlyContinue"
	Import-Module ActiveDirectory
	$Result = Import-Csv $InputFile | Where-Object {($_.GroupSAMAccountName -NE [char]32) -AND ($_.GroupSAMAccountName -NE [char]0)} | Select GroupSAMAccountName, GroupDisplayName, GroupCategory, GroupScope
	New-Item $RepFile -Type File -Force -Value "=========================== UAMGMT STATUS REPORT CREATE NEW ACTIVE DIRECTORY GROUPS ==========================="
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "Task To Execute -- Create New Active Directory Groups"
	Add-Content $RepFile "Create Groups In Location -- $GrpPath"
	Add-Content $RepFile "Report Created On $A"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "`n"
	ForEach ($Grp In $Result) {
		$B = $Grp.GroupSAMAccountName
		$C = $Grp.GroupCategory
		$D = $Grp.GroupScope
		$E = $Grp.GroupDisplayName				
		New-ADGroup -Path $GrpPath -SamAccountName $B -Name $B -GroupCategory $C -GroupScope $D -DisplayName $E -Description "Created With UAMgmt Tool"
		If ($Error) {
			Add-Content $RepFile "`n"
			Add-Content $RepFile "FAILED -- Error Occurred While Attempting To Create New AD Group $B Inside The Location: $GrpPath"
			Add-Content $RepFile "Error -- $Error"
			$Error.Clear()
			Add-Content $RepFile "`n"
		}
		Else {
			Add-Content $RepFile "SUCCESS -- Created New AD Group $B Inside The Location: $GrpPath"
		}
	}
}