Param (
	[String]$RepFile,
	[String]$InputFile,
	[String]$FQDN
)
$A = Get-Date
If (Test-Path $RepFile) {
	Remove-Item $RepFile
}
$UserList = (Import-Csv -Path $InputFile | Where-Object {($_.UserLoginID -NE [char]32) -AND ($_.UserLoginID -NE [char]0)} | Measure-Object).Count
If ($UserList -GT 0) {
	Import-Module ActiveDirectory
	$ErrorActionPreference = "SilentlyContinue"
	$UserList = Import-Csv -Path $InputFile | Where-Object {($_.UserLoginID -NE [char]32) -AND ($_.UserLoginID -NE [char]0)}

	New-Item $RepFile -Type File -Force -Value "=========================== UAMGMT STATUS REPORT DISABLE ACTIVE DIRECTORY USER ACCOUNTS ==========================="
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "Task To Execute -- Disable Active Directory User Accounts In The Domain $FQDN"
	Add-Content $RepFile "Disable Selected User Accounts As Mentioned In The Input File -- $InputFile"
	Add-Content $RepFile "Report Created On $A"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "`n"
	
	FOREACH ($Person In $UserList) {
		$UserName = $Person.UserLoginID.ToUpper()
		Disable-ADAccount -Identity $UserName
		If ($Error) {
			Add-Content $RepFile "`n"
			Add-Content $RepFile "FAILED -- Error Occurred While Attempting To Disable AD User Account: $UserName"
			Add-Content $RepFile "$Error"
			$Error.Clear()
			Add-Content $RepFile "`n"			
		}
		Else {
			Add-Content $RepFile "SUCCESS -- Disabled AD User Account $UserName"
			Add-Content $RepFile "`n"
		}
	}
	Remove-Module ActiveDirectory
}
Else {
	## Input File Is Empty
	New-Item $RepFile -Type File -Force -Value "=========================== UAMGMT STATUS REPORT DISABLE ACTIVE DIRECTORY USER ACCOUNTS ==========================="
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "Task To Execute -- Disable Active Directory User Accounts In The Domain $FQDN"
	Add-Content $RepFile "Disable Selected User Accounts As Mentioned In The Input File -- $InputFile"
	Add-Content $RepFile "Report Created On $A"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "No Active Directory User Account Has Been Disabled."
	Add-Content $RepFile "The Input File $InputFile Contains No Data."
	Add-Content $RepFile "`n"
	Add-Content $RepFile "=================================== UAMGMT END OF STATUS REPORT ==================================="
}