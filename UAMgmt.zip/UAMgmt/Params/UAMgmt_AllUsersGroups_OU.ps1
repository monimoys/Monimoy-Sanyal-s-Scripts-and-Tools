Param (
	[String]$DN,
	[String]$RepFile,
	[String]$ErrRepFile
)
If (Test-Path $RepFile) {
	Remove-Item $RepFile
}
If (Test-Path $ErrRepFile) {
	Remove-Item $ErrRepFile
}
Try {
	Import-Module ActiveDirectory
	$Result = (Get-ADObject -Filter {(ObjectClass -EQ "Group") -OR (ObjectClass -EQ "User")} -SearchBase $DN -SearchScope OneLevel -Properties * | Measure-Object).Count
	If ($Result -GT 0) {
		Get-ADObject -Filter {(ObjectClass -EQ "Group") -OR (ObjectClass -EQ "User")} -SearchBase $DN -SearchScope OneLevel -Properties * | Select @{Name="Name";Expression={$_."SAMAccountName"}}, ObjectClass, DisplayName, @{Name="Protected";Expression={$_."ProtectedFromAccidentalDeletion"}}, WhenCreated, DistinguishedName | Sort-Object Name | Export-CSV $RepFile -NoTypeInformation
	}
	Remove-Module ActiveDirectory	
}
Catch {
	[System.Exception]
}
Finally {
	If ($Error) {
		If (Test-Path $ErrRepFile) {
			Remove-Item $ErrRepFile
		}
		New-Item $ErrRepFile -Type File -Force -Value "=========================== UAMGMT ERROR LOG ========================="
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "Error Occurred While Reporting All User Accounts And Groups Inside Organizational Unit"
		Add-Content $ErrRepFile "Selected Organizational Unit -- $DN"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile $Error
		$Error.Clear()
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "=========================== UAMGMT ERROR LOG ========================="
	}
}