Param (
	[String]$GrpName,
	[String]$RepFile,
	[String]$ErrRepFile
)
$A = Get-Date
If (Test-Path $RepFile) {
	Remove-Item $RepFile
}
If (Test-Path $ErrRepFile) {
	Remove-Item $ErrRepFile
}
Try {
	Import-Module ActiveDirectory
	$Result = (Get-ADGroupMember -Identity $GrpName -Recursive | Select-Object SAMAccountName | Measure-Object).Count
	If ($Result -GT 0) {
		Get-ADGroupMember -Identity $GrpName -Recursive | Select-Object SAMAccountName, ObjectClass, DistinguishedName | Sort-Object SAMAccountName | FT SAMAccountName, ObjectClass, DistinguishedName -A | Out-File "Temp2.txt"
		If (Test-Path $RepFile) {
			Remove-Item $RepFile
		}
		New-Item $RepFile -Type File -Force -value "======================= UAMGMT GROUP MEMBER STATUS REPORT ========================"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "List of All Members, Including Nested Members, of the AD Group $GrpName"
		Add-Content $RepFile "`nReport Created By User Account Management Tool As On $A"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "User Account Management Tool Found The Following User-Accounts As Current Members of The AD Group $GrpName"
		Add-Content $RepFile "`nTotal Count Of Group Members: $Result"
		Add-Content $RepFile "`n------------------------------------------------------------------------------------------"		
		Add-Content -Path $RepFile -Value (Get-Content "Temp2.txt")
		Remove-Item "Temp2.txt"
		Add-Content $RepFile "Total Count Of Group Members: $Result"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "==================== End OF UAMGMT STATUS REPORT ===================="
	}
	Else {
		If (Test-Path $RepFile) {
			Remove-Item $RepFile
		}
		New-Item $RepFile -Type File -Force -value "======================= UAMGMT GROUP MEMBER STATUS REPORT ========================"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "List of All Members, Including Nested Members, of the AD Group $GrpName"
		Add-Content $RepFile "`nReport Created By User Account Management Tool As On $A"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "User Account Management Tool Found No Member In The AD Group $GrpName"
		Add-Content $RepFile "`nTotal Count Of Group Members: $Result"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "==================== End OF UAMGMT STATUS REPORT ===================="
	}
	Remove-Module ActiveDirectory
}
Catch {
	[System.Exception]
}
Finally {
	If ($Error) {
		If (Test-Path $ErrRepFile) {
			Remove-Item $ErrRepFile
		}
		New-Item $ErrRepFile -Type File -Force -value "======================= UAMGMT ERROR LOG ======================="
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "An Error Occurred While User Account Management Tool Attempted To Retrieve All Members of the AD Group $GrpName"
		Add-Content $ErrRepFile "`nReport Created By User Account Management Tool As On $A"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile $Error
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "==================== End of Error Log ===================="
		$Error.Clear()
	}
}

