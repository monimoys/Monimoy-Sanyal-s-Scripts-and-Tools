Param (
	[String]$OUPath,
	[String]$RepFile,
	[String]$InputFile,
	[String]$FQDN
)
$A = Get-Date
If (Test-Path $RepFile) {
	Remove-Item $RepFile
}
$UserList = (Import-Csv -Path $InputFile | Where-Object {($_.UserLoginID -NE [char]32) -AND ($_.UserLoginID -NE [char]0)} | Measure-Object).Count
If ($UserList -GT 0) {
	Import-Module ActiveDirectory
	$ErrorActionPreference = "SilentlyContinue"
	$UserList = Import-Csv -Path $InputFile | Where-Object {($_.UserLoginID -NE [char]32) -AND ($_.UserLoginID -NE [char]0)}

	New-Item $RepFile -Type File -Force -Value "=========================== UAMGMT STATUS REPORT DELETE ACTIVE DIRECTORY USER ACCOUNTS ==========================="
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "Task To Execute -- Delete Active Directory User Accounts In The Domain $FQDN"
	Add-Content $RepFile "Delete User Accounts From Location -- $OUPath"
	Add-Content $RepFile "Report Created On $A"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "`n"
	
	FOREACH ($Person In $UserList) {
		$UserName = $Person.UserLoginID.ToUpper()
		$ChkUser = (Get-ADUser -Filter {SAMAccountName -EQ $UserName} -SearchBase $OUPath -SearchScope SubTree)
		If ($ChkUser) {
			Get-ADUser -Filter {SAMAccountName -EQ $UserName} -SearchBase $OUPath -SearchScope SubTree | Remove-ADUser -Confirm:$False
			If ($Error) {
				Add-Content $RepFile "`n"
				Add-Content $RepFile "FAILED -- Error Occurred While Attempting To Delete AD User Account: $UserName"
				Add-Content $RepFile "AD User Account Cannot Be Deleted"
				Add-Content $RepFile "$Error"
				$Error.Clear()
				Add-Content $RepFile "`n"			
			}
			Else {
				Add-Content $RepFile "SUCCESS -- Deleted AD User Account $UserName"
				Add-Content $RepFile "`n"
			}
		}
		Else {
			Add-Content $RepFile "FAILED -- Cannot Delete The AD User Account $UserName"
			Add-Content $RepFile "This User Object Does Not Exist In The Domain $FQDN"
			Add-Content $RepFile "`n"
		}
	}
	Remove-Module ActiveDirectory
}
Else {
	## Input File Is Empty
	New-Item $RepFile -Type File -Force -Value "=========================== UAMGMT STATUS REPORT DELETE ACTIVE DIRECTORY USER ACCOUNTS ==========================="
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "Task To Execute -- Delete Active Directory User Accounts In The Domain $FQDN"
	Add-Content $RepFile "Delete User Accounts From Location -- $OUPath"
	Add-Content $RepFile "Report Created On $A"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "No Active Directory User Account Has Been Deleted From The Selected Location"
	Add-Content $RepFile "The Input File $InputFile Contains No Data."
	Add-Content $RepFile "`n"
	Add-Content $RepFile "=================================== UAMGMT END OF STATUS REPORT ==================================="
}