Param (
	[String]$InputFile,
	[String]$RepFile
)
$A = Get-Date
If (Test-Path $RepFile) {
	Remove-Item $RepFile
}
$Result = (Import-Csv $InputFile | Where-Object {($_.UserLoginID -NE [char]32) -AND ($_.UserLoginID -NE [char]0) -AND ($_.GroupName -NE [char]32) -AND ($_.GroupName -NE [char]0)} | Measure-Object).Count
If ($Result -EQ 0) {
	New-Item $RepFile -Type File -Force -Value "=================================== UAMGMT STATUS REPORT ADD USERS TO GROUP ==================================="
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "Report Created On $A"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "No Active Directory User-Account Removed From Any Active Directory Group"
	Add-Content $RepFile "The Input File $InputFile Contains No Data."
	Add-Content $RepFile "`n"
	Add-Content $RepFile "=================================== UAMGMT END OF STATUS REPORT ==================================="
}
Else {
	$ErrorActionPreference = "SilentlyContinue"
	Import-Module ActiveDirectory
	$Result = Import-Csv $InputFile | Where-Object {($_.UserLoginID -NE [char]32) -AND ($_.UserLoginID -NE [char]0) -AND ($_.GroupName -NE [char]32) -AND ($_.GroupName -NE [char]0)} | Select UserLoginID, GroupName
	New-Item $RepFile -Type File -Force -Value "=================================== UAMGMT STATUS REPORT ADD USERS TO GROUP ==================================="
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "Report Created On $A"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "`n"
	ForEach ($User In $Result) {
		$B = $User.UserLoginID
		$G = $User.GroupName
		Remove-ADGroupMember -Identity $G -Member $B -Confirm:$False
		If ($Error) {
			Add-Content $RepFile "`n"
			Add-Content $RepFile "FAILED -- Error Occurred While Attempting To Remove User-Account: $B From The Group: $G"
			Add-Content $RepFile "Error -- $Error"
			$Error.Clear()
			Add-Content $RepFile "`n"
		}
		Else {
			Add-Content $RepFile "SUCCESS -- Removed User-Account: $B From The Group: $G"
		}
	}
	Remove-Module ActiveDirectory
}