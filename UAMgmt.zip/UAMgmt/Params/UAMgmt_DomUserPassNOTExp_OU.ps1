Param (
	[String]$OUName,
	[String]$RepFile,
	[String]$ErrRepFile,
	[String]$DN
)
If (Test-Path $RepFile) {
	Remove-Item $RepFile
}
If (Test-Path $ErrRepFile) {
	Remove-Item $ErrRepFile
}
$A = Get-Date
Try {
	Import-Module ActiveDirectory
	$Result = (Search-ADAccount -SearchBase $DN -SearchScope Onelevel -PasswordNeverExpires | Measure-Object).Count 
	If ($Result -GT 0) {
		Search-ADAccount -SearchBase $DN -SearchScope Onelevel -PasswordNeverExpires | Select @{Name="LoginID";Expression={$_."SAMAccountName"}}, ObjectClass, Enabled, PasswordNeverExpires, UserPrincipalName | Sort-Object LoginID | FT LoginID, ObjectClass, Enabled, PasswordNeverExpires, UserPrincipalName -A | Out-File "Temp2.txt"
		New-Item $RepFile -Type File -Force -Value "=================================== UAMGMT STATUS REPORT ALL USER ACCOUNTS PASSWORD NEVER EXPIRES ==================================="
		Add-Content $RepFile "`n"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "Reporting All User-Accounts Whose Password Never Expires In OU -- $OUName"
		Add-Content $RepFile "Selected OU Distinguished Name -- $DN"
		Add-Content $RepFile "`nReport Created On $A"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "-----------------------------------------------------------------------------------------"
		Add-Content $RepFile "`nAll Active Directory User Accounts Whose Password Never Expires In OU -- $OUName"
		Add-Content $RepFile "Total No. of User Accounts Found: $Result"
		Add-Content $RepFile "-----------------------------------------------------------------------------------------"
		Add-Content $RepFile -Value (Get-Content "Temp2.txt")
		Remove-Item "Temp2.txt"
		Add-Content $RepFile "=================================== UAMGMT END OF STATUS REPORT ==================================="
	}
	Else {
		New-Item $RepFile -Type File -Force -Value "=================================== UAMGMT STATUS REPORT ALL USER ACCOUNTS PASSWORD NEVER EXPIRES ==================================="
		Add-Content $RepFile "`n"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "Reporting All User-Accounts Whose Password Never Expires In OU -- $OUName"
		Add-Content $RepFile "Selected OU Distinguished Name -- $DN"
		Add-Content $RepFile "`nReport Created On $A"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "User Account Management Tool Found No User-Account In The Selected OU Whose Password Never Expires"
		Add-Content $RepFile "Total No. of User Accounts Found: $Result"
		Add-Content $RepFile "`n"		
		Add-Content $RepFile "`n=================================== UAMGMT END OF STATUS REPORT ==================================="
	}
	Remove-Module ActiveDirectory
}
Catch {
	[System.Exception]
}
Finally {
	If ($Error) {
		If (Test-Path $ErrRepFile) {
			Remove-Item $ErrRepFile
		}
		New-Item $ErrRepFile -Type File -Force -Value "=========================== UAMGMT ERROR LOG ========================="
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "Error Occurred While Reporting All User Accounts Whose Password Never Expires In OU $OUName"
		Add-Content $RepFile "Selected OU Distinguished Name -- $DN"
		Add-Content $ErrRepFile "`nReport Created On $A" 
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile $Error
		$Error.Clear()
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "=========================== UAMGMT ERROR LOG ========================="
	}
}