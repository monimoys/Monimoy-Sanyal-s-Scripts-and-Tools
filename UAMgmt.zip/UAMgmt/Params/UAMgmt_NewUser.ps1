Param (
	[String]$OUPath,
	[String]$RepFile,
	[String]$InputFile,
	[String]$FQDN
)

$A = Get-Date

If (Test-Path $RepFile) {
	Remove-Item $RepFile
}

$UserList = (Import-Csv -Path $InputFile | Where-Object {($_.UserLoginID -NE [char]32) -AND ($_.UserLoginID -NE [char]0)} | Measure-Object).Count
If ($UserList -GT 0) {
	Import-Module ActiveDirectory
	$ErrorActionPreference = "SilentlyContinue"
	$UserList = Import-Csv -Path $InputFile | Where-Object {($_.UserLoginID -NE [char]32) -AND ($_.UserLoginID -NE [char]0) -AND ($_.FirstName -NE [char]32) -AND ($_.FirstName -NE [char]0) -AND ($_.LastName -NE [char]32) -AND ($_.LastName -NE [char]0) -AND ($_.EMail -NE [char]32) -AND ($_.EMail -NE [char]0) -AND ($_.DefaultPassword -NE [char]32) -AND ($_.DefaultPassword -NE [char]0)}
	
	New-Item $RepFile -Type File -Force -Value "=========================== UAMGMT STATUS REPORT CREATE NEW ACTIVE DIRECTORY USER ACCOUNTS ==========================="
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "Task To Execute -- Create New Active Directory User Accounts In The Domain $FQDN"
	Add-Content $RepFile "Create User Accounts In Location -- $OUPath"
	Add-Content $RepFile "Report Created On $A"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "`n"

	FOREACH ($Person In $UserList) {
		$Username = $Person.UserLoginID.ToUpper()
		$Password = $Person.DefaultPassword
		$ShowName = $Person.FirstName+" "+$Person.LastName
		$UPN = $Username+"@"+$FQDN
 		$HDrive = $Person.HomeDirectory
		$SP = $Person.LoginScriptPath
		$StrMail = $Person.EMail

		# Create Account in Active Directory 
		New-ADUser -Name $ShowName �GivenName $Person.FirstName �Surname $Person.LastName -Description "Created with UAMgmt Tool" -DisplayName $ShowName �SamAccountName $Username -EMail $StrMail -HomeDrive $Person.HomeDrive -HomeDirectory $HDrive -ScriptPath $SP �UserPrincipalName $UPN -Path $OUPath -Enabled $False
		
		If ($Error) {
			Add-Content $RepFile "`n"
			Add-Content $RepFile "FAILED -- Error Occurred While Attempting To Create New AD User $Username"
			Add-Content $RepFile "New AD User Account Location: $OUPath"
			Add-Content $RepFile "$Error"
			$Error.Clear()
			Add-Content $RepFile "`n"
		}		
		Else {
			# Set Password 
			Set-ADAccountPassword -Identity $Username -NewPassword (ConvertTo-SecureString -AsPlainText $Password -Force)
			Set-ADAccountControl $Username -CannotChangePassword $False
			Set-ADUser $Username -ChangepasswordAtLogon $True
 			Set-ADAccountControl $Username -PasswordNeverExpires $False
			Set-ADAccountControl $Username -PasswordNotRequired $False

			Add-Content $RepFile "SUCCESS -- Created New AD User Account $Username"
			Add-Content $RepFile "New AD User Account Location: $OUPath"
			Add-Content $RepFile "User Account Default Password: $Password. This User MUST CHANGE PASSWORD At Next Logon."
			Add-Content $RepFile "UAMgmt Tool Has DISABLED This New AD User Account By Design and By Default."
			Add-Content $RepFile "Please Check and ENABLE This User-Account Only After You Are Satisfied."
			Add-Content $RepFile "`n"
		}
	}
	Remove-Module ActiveDirectory
}
Else {
	## CSV File Is Empty
	New-Item $RepFile -Type File -Force -Value "=========================== UAMGMT STATUS REPORT CREATE NEW ACTIVE DIRECTORY USER ACCOUNTS ==========================="
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "Task To Execute -- Create New Active Directory User Accounts In The Domain $FQDN"
	Add-Content $RepFile "Create User Accounts In Location -- $OUPath"
	Add-Content $RepFile "Report Created On $A"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "No Active Directory User Account Created In The Selected Location"
	Add-Content $RepFile "The Input File $InputFile Contains No Data."
	Add-Content $RepFile "`n"
	Add-Content $RepFile "=================================== UAMGMT END OF STATUS REPORT ==================================="
}