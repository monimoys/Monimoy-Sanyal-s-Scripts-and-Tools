Param (
	[String]$UserName,
	[String]$Pass,
	[String]$RepFile,
	[String]$FQDN
)
$A = Get-Date
If (Test-Path $RepFile) {
	Remove-Item $RepFile
}
Try {
	Import-Module ActiveDirectory
	Set-ADAccountPassword -Identity $UserName -Reset -NewPassword (ConvertTo-SecureString -AsPlainText $Pass -Force)
	Set-ADUser $Username -ChangepasswordAtLogon $True
}
Catch {
	[System.Exception]
}
Finally {
	If ($Error) {
		If (Test-Path $RepFile) {
			Remove-Item $RepFile
		}
		New-Item $RepFile -Type File -Force -Value "====================== UAMGMT STATUS REPORT RESET USER ACCOUNT PASSWORD ======================"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "Task To Execute -- Reset Active Directory User Account Password In The Domain $FQDN"
		Add-Content $RepFile "Status: FAILED. Target AD User Account -- $UserName"
		Add-Content $RepFile "Report Created On $A"
		Add-Content $RepFile "---------------------------------------------------------------------------------------"
		Add-Content $RepFile "---------------------------------------------------------------------------------------"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "An Error Has Occurred While Attempting To Execute The Selected Task:"
		Add-Content $RepFile $Error
		$Error.Clear()
	}
	Remove-Module ActiveDirectory
}

