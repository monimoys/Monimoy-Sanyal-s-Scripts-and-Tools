Param (
	[String]$OUName,
	[String]$RepFile,
	[String]$ErrRepFile,
	[String]$DN
)

$A = Get-Date

If (Test-Path $RepFile) {
	Remove-Item $RepFile
}
If (Test-Path $ErrRepFile) {
	Remove-Item $ErrRepFile
}

Try {
	Import-Module ActiveDirectory
	$Result = (Search-ADAccount -SearchBase $DN -SearchScope OneLevel -AccountDisabled -UsersOnly | Measure-Object).Count
	If ($Result -GT 0) {
		Search-ADAccount -SearchBase $DN -SearchScope OneLevel -AccountDisabled -UsersOnly | Select @{Name="LoginID";Expression={$_."SAMAccountName"}}, ObjectClass, Enabled, UserPrincipalName, DistinguishedName | Sort-Object LoginID | FT LoginID, ObjectClass, Enabled, UserPrincipalName, DistinguishedName -A | Out-File "Temp2.txt"
		New-Item $RepFile -Type File -Force -Value "=================================== UAMGMT STATUS REPORT ALL DISABLED USER ACCOUNTS ==================================="
		Add-Content $RepFile "`n"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "Reporting All Disabled User Accounts In The Selected OU -- $OUName"
		Add-Content $RepFile "OU Distinguished Name -- $DN"
		Add-Content $RepFile "`nReport Created On $A"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "-----------------------------------------------------------------------------------------"
		Add-Content $RepFile "`nAll DISABLED Active Directory User Accounts In The Selected OU $OUName"
		Add-Content $RepFile "Total No. of User Accounts Found: $Result"
		Add-Content $RepFile "-----------------------------------------------------------------------------------------"
		Add-Content $RepFile -Value (Get-Content "Temp2.txt")
		Remove-Item "Temp2.txt"
		Add-Content $RepFile "=================================== UAMGMT END OF STATUS REPORT ==================================="
	}
	Else {
		New-Item $RepFile -Type File -Force -Value "=================================== UAMGMT STATUS REPORT ALL DISABLED USER ACCOUNTS ==================================="
		Add-Content $RepFile "`n"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "Reporting All Disabled User Accounts In OU -- $OUName"
		Add-Content $RepFile "OU Distinguished Name -- $DN"
		Add-Content $RepFile "`nReport Created On $A"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "User Account Management Tool Found No Disabled User Accounts In The Selected OU"
		Add-Content $RepFile "Total No. of User Accounts Found: $Result"
		Add-Content $RepFile "`n"		
		Add-Content $RepFile "`n=================================== UAMGMT END OF STATUS REPORT ==================================="
	}
	Remove-Module ActiveDirectory
}
Catch {
	[System.Exception]
}
Finally {
	If ($Error) {
		If (Test-Path $ErrRepFile) {
			Remove-Item $ErrRepFile
		}
		New-Item $ErrRepFile -Type File -Force -Value "=========================== UAMGMT ERROR LOG ========================="
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "Error Occurred While Reporting All Disabled User Accounts In The OU $OUName"
		Add-Content $ErrRepFile "OU Distinguished Name -- $DN"
		Add-Content $ErrRepFile "`nReport Created On $A" 
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile $Error
		$Error.Clear()
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "=========================== UAMGMT ERROR LOG ========================="
	}
}