Param (
	$SourceOU,
	$DestOU,
	$RepFile
)

$A = Get-Date
If (Test-Path $RepFile) {
	Remove-Item $RepFile
}
If ($Error) {
	$Error.Clear()
}
Import-Module ActiveDirectory
$Result = (Get-ADObject -Filter {(ObjectClass -EQ "User") -AND (ObjectCategory -EQ "User") -AND (SAMAccountName -Like "*")} -Searchbase $SourceOU -SearchScope OneLevel -Properties DistinguishedName | Measure-Object).Count
If ($Result -GT 0) {
	New-Item $RepFile -Type File -Force -value "======================= UAMGMT STATUS REPORT MOVE AD USER ACCOUNTS ONLY ========================"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "Task To Execute -- Move AD User Accounts Only From One OU To Another OU"
	Add-Content $RepFile "`Source OU -- $SourceOU"
	Add-Content $RepFile "`nDestination OU -- $DestOU"
	Add-Content $RepFile "`nReport Generated On: $A"
	Add-Content $RepFile "`n-----------------------------------------------------------------------------------------------------------"
	Add-Content $RepFile "`n-----------------------------------------------------------------------------------------------------------"
	Add-Content $RepFile "`n"

	$Result = (Get-ADObject -Filter {(ObjectClass -EQ "User") -AND (ObjectCategory -EQ "User") -AND (SAMAccountName -Like "*")} -Searchbase $SourceOU -SearchScope OneLevel -Properties DistinguishedName, SAMAccountName, UserPrincipalName, ObjectClass)
	FOREACH ($Person In $Result) {
		$DN = $Person.DistinguishedName.ToUpper()
		$UserName = $Person.SAMAccountName.ToUpper()
		$UPN = $Person.UserPrincipalName
		$ObjClass = $Person.ObjectClass.ToUpper()

		## If ($ShowClass -IEQ "USER") {
			Move-ADObject -Identity $DN -TargetPath $DestOU		
			If ($Error) {
				Add-Content $RepFile "Move AD User Account $UserName ($UPN) -- An Error Has Occurred"
				Add-Content $RepFile "`nSource OU -- $SourceOU"
				Add-Content $RepFile "`nDestination OU -- $DestOU"
				Add-Content $RepFile "`n$Error"
				$Error.Clear()
				Add-Content $RepFile "`n"
			}
			Else {
				Add-Content $RepFile "SUCCESS -- Move AD User Account $UserName ($UPN)"
				Add-Content $RepFile "`nSource OU -- $SourceOU"
				Add-Content $RepFile "`nDestination OU -- $DestOU"
				Add-Content $RepFile "`nObject Has Been Moved To The Destination OU"
				Add-Content $RepFile "`n"
			}
		## }
		## Else {
			## Add-Content $RepFile "There is No Active Directory User Account Inside The Source OU To Move To The Target OU."
			## Add-Content $RepFile "`nNo User Account Has Been Moved From Source OU To Target OU."
			## Add-Content $RepFile "`n"
		## }		
	}
}
Else {
	If (Test-Path $RepFile) {
		Remove-Item $RepFile
	}
	New-Item $RepFile -Type File -Force -value "======================= UAMGMT STATUS REPORT MOVE AD USER ACCOUNTS ONLY ========================"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "Task To Execute -- Move AD User Accounts Only From One OU To Another OU"
	Add-Content $RepFile "`Source OU -- $SourceOU"
	Add-Content $RepFile "`nDestination OU -- $DestOU"
	Add-Content $RepFile "`nReport Generated On: $A"
	Add-Content $RepFile "`n-----------------------------------------------------------------------------------------------------------"
	Add-Content $RepFile "`n-----------------------------------------------------------------------------------------------------------"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "There is No Active Directory User Account Inside The Source OU To Move To The Target OU."
	Add-Content $RepFile "`nNo User Account Has Been Moved From Source OU To Target OU."
	Add-Content $RepFile "`n"
	Add-Content $RepFile "============================ End of Status Report ============================"
	
}
Remove-Module ActiveDirectory