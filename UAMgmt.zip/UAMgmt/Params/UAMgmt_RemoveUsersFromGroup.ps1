Param (
	[String]$InputFile,
	[String]$GroupName,
	[String]$RepFile
)
$A = Get-Date
If (Test-Path $RepFile) {
	Remove-Item $RepFile
}
$Result = (Import-Csv $InputFile | Where-Object {($_.UserLoginID -NE [char]32) -AND ($_.UserLoginID -NE [char]0)} | Measure-Object).Count
If ($Result -EQ 0) {
	New-Item $RepFile -Type File -Force -Value "=================================== UAMGMT STATUS REPORT ADD USERS TO GROUP ==================================="
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "Selected Group -- $GroupName"
	Add-Content $RepFile "Report Created On $A"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "No Active Directory User Account Removed From The Selected Group $GroupName"
	Add-Content $RepFile "The Input File $InputFile Contains No User Login ID."
	Add-Content $RepFile "Total No. of User Accounts Found In The Input File: $Result"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "=================================== UAMGMT END OF STATUS REPORT ==================================="
}
Else {
	$ErrorActionPreference = "SilentlyContinue"
	Import-Module ActiveDirectory
	$Result = Import-Csv $InputFile | Where-Object {($_.UserLoginID -NE [char]32) -AND ($_.UserLoginID -NE [char]0)} | Select @{Name="UserLoginID";Expression={$_."UserLoginID"}}
	New-Item $RepFile -Type File -Force -Value "=================================== UAMGMT STATUS REPORT ADD USERS TO GROUP ==================================="
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "Selected Group -- $GroupName"
	Add-Content $RepFile "Report Created On $A"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "`n"
	ForEach ($User In $Result) {
		$B = $User.UserLoginID
		Remove-ADGroupMember -Identity $GroupName -Member $B -Confirm:$False
		If ($Error) {
			Add-Content $RepFile "`n"
			Add-Content $RepFile "FAILED -- Error Occurred While Attempting To Remove User-Account: $B From The Selected Group: $GroupName"
			Add-Content $RepFile "Error -- $Error"
			$Error.Clear()
			Add-Content $RepFile "`n"
		}
		Else {
			Add-Content $RepFile "SUCCESS -- Removed User-Account: $B From The Selected Group: $GroupName"
		}
	}
	Remove-Module ActiveDirectory
}