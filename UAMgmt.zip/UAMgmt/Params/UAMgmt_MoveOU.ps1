Param (
	$SourceOU,
	$DestOU,
	$RepFile
)

$A = Get-Date
If (Test-Path $RepFile) {
	Remove-Item $RepFile
}
If ($Error) {
	$Error.Clear()
}
Import-Module ActiveDirectory
$Result = (Get-ADObject -Filter {(ObjectClass -EQ "User") -OR (ObjectClass -EQ "Group")} -Searchbase $SourceOU -SearchScope OneLevel -Properties DistinguishedName | Measure-Object).Count
If ($Result -GT 0) {
	New-Item $RepFile -Type File -Force -value "======================= UAMGMT STATUS REPORT MOVE AD USERS AND GROUPS ========================"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "Task To Execute -- Move AD Users And Groups From One OU To Another OU"
	Add-Content $RepFile "`Source OU -- $SourceOU"
	Add-Content $RepFile "`nDestination OU -- $DestOU"
	Add-Content $RepFile "`nReport Generated On: $A"
	Add-Content $RepFile "`n-----------------------------------------------------------------------------------------------------------"
	Add-Content $RepFile "`n-----------------------------------------------------------------------------------------------------------"
	Add-Content $RepFile "`n"

	$Result = (Get-ADObject -Filter {(ObjectClass -EQ "User") -AND (ObjectCategory -EQ "User") -OR (ObjectClass -EQ "Group") -AND (ObjectCategory -EQ "Group")} -Searchbase $SourceOU -SearchScope OneLevel -Properties DistinguishedName, SAMAccountName, DisplayName, ObjectClass)
	FOREACH ($Person In $Result) {
		$DN = $Person.DistinguishedName.ToUpper()
		$UserName = $Person.SAMAccountName.ToUpper()
		$Show = $Person.DisplayName
		$ShowClass = $Person.ObjectClass.ToUpper()

		### If (($dow -eq "Saturday") -or ($dow -eq "Sunday"))

		If (($ShowClass -IEQ "USER") -OR ($ShowClass -IEQ "GROUP") -AND ($DN -NE $Null)) {
			Move-ADObject -Identity $DN -TargetPath $DestOU
			If ($Error) {
				If ($ShowClass -IEQ "USER") {
					Add-Content $RepFile "FAILED -- Move AD Object $UserName ($ShowClass -- $Show) -- An Error Has Occurred"
				}
				Else {
					Add-Content $RepFile "FAILED -- Move AD Object $UserName ($ShowClass) -- An Error Has Occurred"
				}
				Add-Content $RepFile "`nSource OU -- $SourceOU"
				Add-Content $RepFile "`nDestination OU -- $DestOU"
				Add-Content $RepFile "`n$Error"
				$Error.Clear()
				Add-Content $RepFile "`n"
			}
			Else {
				If ($ShowClass -IEQ "USER") {
					Add-Content $RepFile "SUCCESS -- Move AD Object $UserName ($ShowClass -- $Show)"
				}
				Else {
					Add-Content $RepFile "SUCCESS -- Move AD Object $UserName ($ShowClass)"
				}
				Add-Content $RepFile "`nSource OU -- $SourceOU"
				Add-Content $RepFile "`nDestination OU -- $DestOU"
				Add-Content $RepFile "`nObject Has Been Moved To The Destination OU"
				Add-Content $RepFile "`n"
			}		
		}
		Else {
			If ($Error) {
				$Error.Clear()
			}
			Add-Content $RepFile "There is No Active Directory User Account OR Group Inside The Source OU To Move To The Target OU."
			Add-Content $RepFile "`nNo AD Object Has Been Moved From Source OU To Target OU."
			Add-Content $RepFile "`n"	
		}
	}
}
Else {
	If (Test-Path $RepFile) {
		Remove-Item $RepFile
	}
	New-Item $RepFile -Type File -Force -value "======================= UAMGMT STATUS REPORT MOVE AD USERS AND GROUPS ========================"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "Task To Execute -- Move AD Users And Groups From One OU To Another OU"
	Add-Content $RepFile "`Source OU -- $SourceOU"
	Add-Content $RepFile "`nDestination OU -- $DestOU"
	Add-Content $RepFile "`nReport Generated On: $A"
	Add-Content $RepFile "`n-----------------------------------------------------------------------------------------------------------"
	Add-Content $RepFile "`n-----------------------------------------------------------------------------------------------------------"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "There is No Active Directory User Account OR Group Inside The Source OU To Move To The Target OU."
	Add-Content $RepFile "`nNo AD Object Has Been Moved From Source OU To Target OU."
	Add-Content $RepFile "`n"
	Add-Content $RepFile "============================ End of Status Report ============================"
	
}
Remove-Module ActiveDirectory