Param (
	[String]$RepFile,
	[String]$ErrRepFile,
	[String]$FQDN
)
If (Test-Path $RepFile) {
	Remove-Item $RepFile
}
If (Test-Path $ErrRepFile) {
	Remove-Item $ErrRepFile
}
Try {
	Import-Module ActiveDirectory
	$Result = (Get-ADUser -Filter {(SAMAccountName -Like "*")} -Properties * | ? {$_.UserPrincipalName -NE $NULL} | Measure-Object).Count
	If ($Result -GT 0) {
		$AllUsers = Get-ADUser -Filter {(SAMAccountName -Like "*")} -Properties * | ? {$_.UserPrincipalName -NE $NULL} | Select SAMAccountName, Name, UserPrincipalName, Enabled, LockedOut, PasswordExpired, PasswordNeverExpires, PasswordNotRequired, HomeDirectory, HomeDrive, ScriptPath, ProtectedFromAccidentalDeletion, WhenCreated, WhenChanged, DistinguishedName | Sort-Object SAMAccountName | Export-CSV $RepFile -NoTypeInformation
	}
	Remove-Module ActiveDirectory
}
Catch {
	[System.Exception]
}
Finally {
	If ($Error) {
		If (Test-Path $ErrRepFile) {
			Remove-Item $ErrRepFile
		}
		New-Item $ErrRepFile -Type File -Force -Value "=========================== UAMGMT ERROR LOG ========================="
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "Error Occurred While Reporting All Active Directory User Accounts In The Domain $FQDN"
		Add-Content $ErrRepFile "`nReport Created On $A" 
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile $Error
		$Error.Clear()
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "=========================== UAMGMT ERROR LOG ========================="
	}
}