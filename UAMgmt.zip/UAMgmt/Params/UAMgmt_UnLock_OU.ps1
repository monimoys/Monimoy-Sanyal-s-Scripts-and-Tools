Param (
	[String]$OUPath,
	[String]$RepFile,
	[String]$FQDN
)

$A = Get-Date
If (Test-Path $RepFile) {
	Remove-Item $RepFile
}

$ErrorActionPreference = "SilentlyContinue"
Import-Module ActiveDirectory
$Result = (Get-ADUser -Filter {(ObjectClass -EQ "User") -AND (ObjectCategory -EQ "User") -AND (SAMAccountName -Like "*")} -SearchBase $OUPath -SearchScope OneLevel | Measure-Object).Count
If ($Result -GT 0) {
	New-Item $RepFile -Type File -Force -Value "====================== UAMGMT STATUS REPORT UNLOCK AD USER ACCOUNT ======================"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "Task To Execute -- Unlock All Active Directory User Accounts Inside One Specific OU"
	Add-Content $RepFile "Selected OU -- $OUPath"
	Add-Content $RepFile "Report Created On $A"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "`n"
	
	$UserList = (Get-ADUser -Filter {(ObjectClass -EQ "User") -AND (ObjectCategory -EQ "User") -AND (SAMAccountName -Like "*")} -SearchBase $OUPath -SearchScope OneLevel | Select SAMAccountName, UserPrincipalName | Sort-Object SAMAccountName)
	FOREACH ($Person In $UserList) {
		$UserName = $Person.SAMAccountName.ToUpper()
		$UPN = $Person.UserPrincipalName
		Unlock-ADAccount -Identity $UserName
		If ($Error) {
			Add-Content $RepFile "`n"
			Add-Content $RepFile "FAILED -- Error Occurred While Attempting To Un-Lock AD User Account In The Domain: $FQDN"
			Add-Content $RepFile "Target User Account: $UserName ($UPN)"
			Add-Content $RepFile "Selected OU -- $OUPath"
			Add-Content $RepFile "$Error"
			$Error.Clear()
			Add-Content $RepFile "`n"
		}
		Else {
			Add-Content $RepFile "SUCCESS -- Un-Locked The AD User Account $UserName ($UPN)"
			Add-Content $RepFile "Selected OU -- $OUPath"
			Add-Content $RepFile "`n"
		}
	}
}
Else {
	## No User In OU
	If (Test-Path $RepFile) {
		Remove-Item $RepFile
	}
	New-Item $RepFile -Type File -Force -Value "====================== UAMGMT STATUS REPORT UNLOCK AD USER ACCOUNT ======================"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "Task To Execute -- Unlock All Active Directory User Accounts Inside One Specific OU"
	Add-Content $RepFile "Selected OU -- $OUPath"
	Add-Content $RepFile "Report Created On $A"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "No Active Directory User Account Has Been Unlocked."
	Add-Content $RepFile "The Selected OU Does Not Contain Any User Account."
	Add-Content $RepFile "`n"
	Add-Content $RepFile "=================================== UAMGMT END OF STATUS REPORT ==================================="
}
Remove-Module ActiveDirectory