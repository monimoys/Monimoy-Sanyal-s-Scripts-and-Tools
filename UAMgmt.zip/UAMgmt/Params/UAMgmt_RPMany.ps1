Param (
	[String]$InputFile,
	[String]$RepFile,
	[String]$FQDN
)

$A = Get-Date
If (Test-Path $RepFile) {
	Remove-Item $RepFile
}

$UserList = (Import-Csv -Path $InputFile | Where-Object {($_.UserLoginID -NE [char]32) -AND ($_.UserLoginID -NE [char]0) -AND ($_.DefaultPassword -NE [char]32) -AND ($_.DefaultPassword -NE [char]0)} | Measure-Object).Count
If ($UserList -GT 0) {
	Import-Module ActiveDirectory
	$ErrorActionPreference = "SilentlyContinue"
	$UserList = Import-Csv -Path $InputFile | Where-Object {($_.UserLoginID -NE [char]32) -AND ($_.UserLoginID -NE [char]0) -AND ($_.DefaultPassword -NE [char]32) -AND ($_.DefaultPassword -NE [char]0)}
	
	New-Item $RepFile -Type File -Force -Value "====================== UAMGMT STATUS REPORT RESET USER ACCOUNT PASSWORD ======================"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "Task To Execute -- Reset Active Directory User Account Password In The Domain $FQDN"
	Add-Content $RepFile "Report Created On $A"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "`n"

	FOREACH ($Person In $UserList) {
		$UserName = $Person.UserLoginID.ToUpper()
		$Password = $Person.DefaultPassword
		# Reset The AD User Account Password Now
		Set-ADAccountPassword -Identity $UserName -Reset -NewPassword (ConvertTo-SecureString -AsPlainText $Password -Force)
		Set-ADUser $Username -ChangepasswordAtLogon $True		
		If ($Error) {
			Add-Content $RepFile "`n"
			Add-Content $RepFile "FAILED -- Error Occurred While Attempting To Reset Password of AD User Account."
			Add-Content $RepFile "Target User Account -- $UserName"
			Add-Content $RepFile "$Error"
			$Error.Clear()
			Add-Content $RepFile "`n"
		}		
		Else {
			Add-Content $RepFile "SUCCESS -- Password Has Been Reset For AD User Account $UserName"
			Add-Content $RepFile "This User MUST CHANGE PASSWORD At Next Logon."
			Add-Content $RepFile "`n"
		}
	}
	Remove-Module ActiveDirectory
}
Else {
	## CSV File Does Not Have The Required Data
	New-Item $RepFile -Type File -Force -Value "====================== UAMGMT STATUS REPORT RESET USER ACCOUNT PASSWORD ======================"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "Task To Execute -- Reset Active Directory User Account Password In The Domain $FQDN"
	Add-Content $RepFile "Report Created On $A"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "No Active Directory User Account Password Has Been Reset"
	Add-Content $RepFile "The Input File $InputFile Does Not Contain Correct Data."
	Add-Content $RepFile "`n"
	Add-Content $RepFile "=================================== UAMGMT END OF STATUS REPORT ==================================="
}