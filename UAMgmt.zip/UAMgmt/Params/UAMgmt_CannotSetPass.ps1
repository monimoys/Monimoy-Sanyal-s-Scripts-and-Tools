Param (
	[String]$InputFile,
	[String]$RepFile,
	[String]$OUPath,
	[String]$FQDN
)
$A = Get-Date
If (Test-Path $RepFile) {
	Remove-Item $RepFile
}
$UserList = (Import-Csv -Path $InputFile | Where-Object {($_.UserLoginID -NE [char]32) -AND ($_.UserLoginID -NE [char]0)} | Measure-Object).Count
If ($UserList -GT 0) {
	Import-Module ActiveDirectory
	$ErrorActionPreference = "SilentlyContinue"
	$UserList = Import-Csv -Path $InputFile | Where-Object {($_.UserLoginID -NE [char]32) -AND ($_.UserLoginID -NE [char]0)}

	New-Item $RepFile -Type File -Force -Value "=========================== UAMGMT STATUS REPORT AD USER ACCOUNTS CONTROL SETTINGS ==========================="
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "Task To Execute -- Prevent AD User Accounts To Change Its Own Password In The Domain $FQDN"
	Add-Content $RepFile "Target User Accounts From Location -- $OUPath"
	Add-Content $RepFile "Report Created On $A"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "`n"
	
	FOREACH ($Person In $UserList) {
		$UserName = $Person.UserLoginID.ToUpper()
		$ChkUser = (Get-ADUser -Filter {SAMAccountName -EQ $UserName} -SearchBase $OUPath -SearchScope SubTree -Property SAMAccountName, DistinguishedName | Measure-Object).Count
		If ($ChkUser -GT 0) {
			$ThisUser = (Get-ADUser -Filter {SAMAccountName -EQ $UserName} -SearchBase $OUPath -SearchScope SubTree -Property * | Select SAMAccountName, DistinguishedName, UserPrincipalName)
			FOREACH($ParkUser In $ThisUser) {
				$WorkNow = $ParkUser.DistinguishedName.ToUpper()
				$UserSAM = $ParkUser.SAMAccountName.ToUpper()
				$UPN = $ParkUser.UserPrincipalName
				Set-ADAccountControl $WorkNow -CannotChangePassword $True -Confirm:$False
				If ($Error) {
					Add-Content $RepFile "`n"
					Add-Content $RepFile "FAILED -- Error Occurred While Attempting Set User Account Control Setting"
					Add-Content $RepFile "Target User Account -- $UserSAM ($UPN)"
					Add-Content $RepFile "AD User Account Cannot Be Denied Permission To Change Its Own Password."
					Add-Content $RepFile "$Error"
					$Error.Clear()
					Add-Content $RepFile "`n"			
				}
				Else {
					Add-Content $RepFile "SUCCESS -- Target User Account: $UserSAM ($UPN)"
					Add-Content $RepFile "SUCCESS -- This AD User Account Cannot Change Its Own Password."
					Add-Content $RepFile "`n"
				}
			}			
		}
		Else {
			Add-Content $RepFile "FAILED -- Cannot Delete The AD User Account $UserName"
			Add-Content $RepFile "This User Object Does Not Exist In The Domain $FQDN"
			Add-Content $RepFile "`n"
		}
		If ($Error) {
			$Error.Clear()
		}
	}
	Remove-Module ActiveDirectory
}
Else {
	## Input File Is Empty
	New-Item $RepFile -Type File -Force -Value "=========================== UAMGMT STATUS REPORT AD USER ACCOUNTS CONTROL SETTINGS ==========================="
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "Task To Execute -- Prevent AD User Accounts To Change Its Own Password In The Domain $FQDN"
	Add-Content $RepFile "Target User Accounts From Location -- $OUPath"
	Add-Content $RepFile "Report Created On $A"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "---------------------------------------------------------------------------------------"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "No Active Directory User Account Has Been Touched For Task-Execution From The Selected Location $OUPath"
	Add-Content $RepFile "Reason -- The Input File $InputFile Contains No Data."
	Add-Content $RepFile "`n"
	Add-Content $RepFile "=================================== UAMGMT END OF STATUS REPORT ==================================="
}