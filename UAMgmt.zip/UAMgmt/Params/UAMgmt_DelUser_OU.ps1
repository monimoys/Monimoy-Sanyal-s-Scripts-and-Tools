Param (
	[String]$OUPath,
	[String]$RepFile,
	[String]$FQDN
)
$A = Get-Date
If (Test-Path $RepFile) {
	Remove-Item $RepFile
}

Import-Module ActiveDirectory
$ErrorActionPreference = "SilentlyContinue"

New-Item $RepFile -Type File -Force -Value "=========================== UAMGMT STATUS REPORT DELETE ACTIVE DIRECTORY USER ACCOUNTS ==========================="
Add-Content $RepFile "`n"
Add-Content $RepFile "`n"
Add-Content $RepFile "Task To Execute -- Delete Active Directory User Accounts In The Domain $FQDN"
Add-Content $RepFile "Delete User Accounts From Location -- $OUPath"
Add-Content $RepFile "Report Created On $A"
Add-Content $RepFile "---------------------------------------------------------------------------------------"
Add-Content $RepFile "---------------------------------------------------------------------------------------"
Add-Content $RepFile "`n"
$ChkUser = (Get-ADUser -Filter {(ObjectClass -EQ "User") -AND (ObjectCategory -EQ "User") -AND (SAMAccountName -Like "*")} -SearchBase $OUPath -SearchScope OneLevel | Measure-Object).Count
If ($ChkUser -GT 0) {
	Get-ADUser -Filter {(ObjectClass -EQ "User") -AND (ObjectCategory -EQ "User") -AND (SAMAccountName -Like "*")} -SearchBase $OUPath -SearchScope OneLevel | Select SAMAccountName, UserPrincipalName | Sort-Object SAMAccountName | FT SAMAccountName, UserPrincipalName -A | Out-File "Temp2.txt"
	Get-ADUser -Filter {(ObjectClass -EQ "User") -AND (ObjectCategory -EQ "User") -AND (SAMAccountName -Like "*")} -SearchBase $OUPath -SearchScope OneLevel | Remove-ADUser -Confirm:$False
	If ($Error) {
		Add-Content $RepFile "`n"
		Add-Content $RepFile "FAILED -- Error Occurred While Attempting To Delete AD User Account"
		Add-Content $RepFile "AD User Account Cannot Be Deleted"
		Add-Content $RepFile "$Error"
		$Error.Clear()
		Add-Content $RepFile "`n"			
	}
	Else {
		Add-Content $RepFile "SUCCESS -- Deleted Total Number of AD User Account: $ChkUser"
		Add-Content $RepFile "AD User Accounts Deleted Are Listed Below:"
		Add-Content $RepFile -Value (Get-Content "Temp2.txt")
		Remove-Item "Temp2.txt"
		Add-Content $RepFile "`n"
	}
}
Else {
	Add-Content $RepFile "FAILED -- Cannot Delete Any AD User Account In $OUPath"
	Add-Content $RepFile "This OU Does Not Have Any User Object Inside It."
	Add-Content $RepFile "`n"
}
Remove-Module ActiveDirectory