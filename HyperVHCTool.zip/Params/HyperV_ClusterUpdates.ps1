Param
(
	[String]$HyperHostName,
	[String]$RepFile
)
$ErrorActionPreference = "SilentlyContinue"
## -- Getting current execution path
$ScriptPath = $MyInvocation.MyCommand.Path
$Dir = Split-Path $ScriptPath

$T = Get-Date
If (Test-Path $RepFile) {
	Remove-Item $RepFile
}
If ($Error) {
	$Error.Clear()
}
New-Item $RepFile -Type File -Force -Value "REPORT: Hyper-V Host $HyperHostName Cluster Update Check" | Out-Null
Add-Content $RepFile "`n"
Add-Content $RepFile "Report Created On $T"
Add-Content $RepFile "============================================================================"
Add-Content $RepFile "`n"

Write-Host "`tCurrent Status: Checking For Missing Hyper-V Cluster Updates" -ForegroundColor "Yellow"

## -- Loading list of updates from XML files
[xml]$SourceFileCluster = Get-Content $Dir\UpdatesListCluster.xml
If ($Error) {
	Add-Content $RepFile "$HyperHostName -- An Error Has Occurred."
	Add-Content $RepFile $Error
	$Error.Clear()
}
$ClusterHotfixes = $SourceFileCluster.Updates.update
If ($Error) {
	Add-Content $RepFile "$HyperHostName -- An Error Has Occurred."
	Add-Content $RepFile $Error
	$Error.Clear()
}

## -- Getting Hotfixes installed on the specified Hyper-V Host
ForEach ($VMHost In $HyperHostName) {
	$Hotfixes = Get-HotFix -ComputerName $VMHost | Select HotfixID, Description
	If ($Error) {
		Add-Content $RepFile "$HyperHostName -- An Error Has Occurred."
		Add-Content $RepFile $Error
		$Error.Clear()
	}
	Else {
		Add-Content $RepFile "Hyper-V Server: $HyperHostName"
		Add-Content $RepFile "COLLECTING HOTFIXES ON HYPER-V HOST: $HyperHostName"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "Listing Failover Cluster 2012 R2 Hotfixes"
		Add-Content $RepFile "---------------------------------------"
		ForEach ($RecomendedClusterHotfix In $ClusterHotfixes) {
        		$Witness = 0
        		ForEach ($Hotfix In $Hotfixes) {
				If($RecomendedClusterHotfix.ID -EQ $Hotfix.HotfixID) {
					Add-Content $RepFile "`t$($RecomendedClusterHotfix.Description)"
                    			Add-Content $RepFile "`t$($RecomendedClusterHotfix.ID) Installed" 
                    			Add-Content $RepFile "`n"
                    			$Witness = 1
                 		}
        		}  
        		If($Witness -eq 0) {
				Add-Content $RepFile "`t$($RecomendedClusterHotfix.Description)"
            			Add-Content $RepFile "`t$($RecomendedClusterHotfix.ID) *** NOT INSTALLED ***" 
            			Add-Content $RepFile "`n"
			}
		}
	}
}