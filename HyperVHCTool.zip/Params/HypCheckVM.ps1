Param (
	[String]$MachName,
	[String]$RepFile,
	[String]$ErrRepFile
)
$ErrorActionPreference = "SilentlyContinue"
$DT = Get-Date
If ($Error) {
	$Error.Clear()
}
If (Test-Path $RepFile) {
	Remove-Item $RepFile
}
If (Test-Path $ErrRepFile) {
	Remove-Item $ErrRepFile
}
$Res = Get-WMIObject -ComputerName $MachName -Query "Select * From Win32_Service Where Name='vmms'" | Select-Object -Property Status, State
If (-Not($Error)) {
	If (($Res.Status -IEQ "OK") -AND ($Res.State -IEQ "Running")) {
		## -- Import-Module Hyper-V
		If (!($Error)) {
			$MemDemandGB = @{Name="MemoryDemand(GB)";Expression={[Math]::Round(($_.MemoryDemand / 1073741824),2)}}
			$MemAssigned = @{Name="MemoryAssigned(GB)";Expression={[Math]::Round(($_.MemoryAssigned / 1073741824),2)}}
			Get-VM -ComputerName $MachName | Select-Object -Property @{Name="VMName";Expression={$_.Name}}, @{Name="Hyper-V Host Name";Expression={$_.ComputerName}}, State, @{Name="IntegrationServicesInstalled";Expression={$_.IntegrationServicesVersion}}, CPUUsage, $MemDemandGB, $MemAssigned, MemoryStatus, Uptime, Status | Export-CSV -Path $RepFile -NoTypeInformation
		}
		Else {
			If (!(Test-Path $ErrRepFile)) {
				New-Item $ErrRepFile -Type File -Force -Value "ERROR REPORT: Hyper-V Physical Host VMs Health Check" | Out-Null
				Add-Content $ErrRepFile "`n"
				Add-Content $ErrRepFile "Error Report Created On $DT"
				Add-Content $ErrRepFile "============================================================================"
				Add-Content $ErrRepFile "`n"
			}
			Add-Content $ErrRepFile $Error
			$Error.Clear()
			Add-Content $ErrRepFile "Ensure that PowerShell Module For Failover Clusters AND Hyper-V Are Properly Installed On This Computer."
		}
	}
	Else {
		If (!(Test-Path $ErrRepFile)) {
			New-Item $ErrRepFile -Type File -Force -Value "ERROR REPORT: Hyper-V Physical Host VMs Health Check" | Out-Null
			Add-Content $ErrRepFile "`n"
			Add-Content $ErrRepFile "Error Report Created On $DT"
			Add-Content $ErrRepFile "============================================================================"
			Add-Content $ErrRepFile "`n"
		}
		Add-Content $ErrRepFile $Error
		$Error.Clear()
		Add-Content $ErrRepFile "Hyper-V Services Are Not Working Correctly On Target Hyper-V Server $MachName."
	}
}
Else {
	If (!(Test-Path $ErrRepFile)) {
		New-Item $ErrRepFile -Type File -Force -Value "ERROR REPORT: Hyper-V Physical Host VMs Health Check" | Out-Null
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "Error Report Created On $DT"
		Add-Content $ErrRepFile "============================================================================"
		Add-Content $ErrRepFile "`n"
	}
	Add-Content $ErrRepFile $Error
	$Error.Clear()
	Add-Content $ErrRepFile "Ensure that The Hyper-V Server: $MachName and Hyper-V Services are Up and Running. This Server Cannot Be Contacted At This Time."
	Add-Content $ErrRepFile "Ensure that PowerShell Module For Failover Clusters AND Hyper-V Are Properly Installed On This Computer."
}