[CmdletBinding(SupportsShouldProcess=$True)]
Param(
	[Parameter(Mandatory = $True)]
	[String]$MachName,
	[Parameter(Mandatory = $True)]
	[String]$TestType
)
Function ZipFiles($ZipFileName, $SourceFolder) {
	Add-Type -Assembly System.IO.Compression.FileSystem
	$CompressionLevel = [System.IO.Compression.CompressionLevel]::Optimal
	[System.IO.Compression.ZipFile]::CreateFromDirectory($SourceFolder, $ZipFileName, $CompressionLevel, $False)
}
$ErrorActionPreference = "SilentlyContinue"
Write-Host
Write-Host "Starting Health Checks. Please wait ..."
Write-Host

$A = Get-Date -Format "ddMMMMyyyyHHmmss"
$A = $A -Replace ",", $Null
$A = $A -Replace ":", $Null
$A = $A -Replace " ", $Null
$A = $A -Replace "-", $Null
$A = $A -Replace "/", $Null
$FilesToZip = $A + "_BackUpReport.zip"
$This = Split-Path -Parent $PSCommandPath
$ActualPath = Split-Path $This -Parent

If (!(Test-Path "$ActualPath\Reports" -PathType Container)) {
	New-Item "$ActualPath\Reports" -Type Directory | Out-Null
}
$Res = (Get-ChildItem "$ActualPath\Reports" | Measure-Object).Count
If (($Res -GT 0) -AND (!(Test-Path "$ActualPath\BackUpReports" -PathType Container))) {
	New-Item "$ActualPath\BackUpReports" -Type Directory | Out-Null
}
If (($Res -GT 0) -AND (Test-Path "$ActualPath\BackUpReports" -PathType Container)) {
	Write-Host "`tCurrent Status: Backing-Up Historical Reports." -ForegroundColor "Yellow"
	ZipFiles "$ActualPath\BackUpReports\$FilesToZip" "$ActualPath\Reports"
	Remove-Item "$ActualPath\Reports\*.*" -Recurse -Force
}

If ($TestType -IEQ "AllChecks") {
	Write-Host "`tCurrent Status: Checking Physical Hyper-V Host $MachName" -ForegroundColor "Yellow"
	Invoke-Expression "$This\HypHost.ps1 '$MachName' '$ActualPath\Reports\Report_HyperVHostCheck.csv' '$ActualPath\Reports\Error_HyperVHostCheck.txt'" | Out-Null

	Write-Host "`tCurrent Status: Checking Hyper-V Host Cluster" -ForegroundColor "Yellow"
	Invoke-Expression "$This\HypClus.ps1 '$MachName' '$ActualPath\Reports'" | Out-Null

	Write-Host "`tCurrent Status: Checking VMs Inside Physical Hyper-V Host $MachName" -ForegroundColor "Yellow"
	Invoke-Expression "$This\HypCheckVM.ps1 '$MachName' '$ActualPath\Reports\Report_VMsHyperVCheck.csv' '$ActualPath\Reports\Error_VMsHyperVCheck.txt'" | Out-Null
	Invoke-Expression "$This\HyperV_OnlyUpdates.ps1 '$MachName' '$ActualPath\Reports\Report_HyperVUpdates.txt'" | Out-Null
	Invoke-Expression "$This\HyperV_ClusterUpdates.ps1 '$MachName' '$ActualPath\Reports\Report_HyperVClusterUpdates.txt'" | Out-Null

	Write-Host
	Write-Host "Health Check Activities Completed. Check Reports From:"
	Write-Host "$ActualPath\Reports"
	Write-Host
}

If ($TestType -IEQ "HostOnly") {
	Write-Host "`tCurrent Status: Checking Physical Hyper-V Host $MachName" -ForegroundColor "Yellow"
	Invoke-Expression "$This\HypHost.ps1 '$MachName' '$ActualPath\Reports\Report_HyperVHostCheck.csv' '$ActualPath\Reports\Error_HyperVHostCheck.txt'" | Out-Null
	Write-Host
	Write-Host "Hyper-V Host $MachName Health Check Completed. Check Reports From:"
	Write-Host "$ActualPath\Reports"
	Write-Host
}

If ($TestType -IEQ "ClusterOnly") {
	Write-Host "`tCurrent Status: Checking Hyper-V Host Cluster" -ForegroundColor "Yellow"
	Invoke-Expression "$This\HypClus.ps1 '$MachName' '$ActualPath\Reports'" | Out-Null
	Write-Host
	Write-Host "Hyper-V Host Cluster Health Check Completed. Check Reports From:"
	Write-Host "$ActualPath\Reports"
	Write-Host
}

If ($TestType -IEQ "VMOnly") {
	Write-Host "`tCurrent Status: Checking VMs Inside Physical Hyper-V Host $MachName" -ForegroundColor "Yellow"
	Invoke-Expression "$This\HypCheckVM.ps1 '$MachName' '$ActualPath\Reports\Report_VMsHyperVCheck.csv' '$ActualPath\Reports\Error_VMsHyperVCheck.txt'" | Out-Null
	Write-Host
	Write-Host "Health Check of VMs Inside Hyper-V Host $MachName Completed. Check Reports From:"
	Write-Host "$ActualPath\Reports"
	Write-Host
}

If ($TestType -IEQ "UpdateOnly") {
	Invoke-Expression "$This\HyperV_OnlyUpdates.ps1 '$MachName' '$ActualPath\Reports\Report_HyperVUpdates.txt'" | Out-Null
	Invoke-Expression "$This\HyperV_ClusterUpdates.ps1 '$MachName' '$ActualPath\Reports\Report_HyperVClusterUpdates.txt'" | Out-Null
	Write-Host
	Write-Host "Hyper-V and Cluster Updates Check Completed. Check Reports From:"
	Write-Host "$ActualPath\Reports"
	Write-Host
}