Param (
	[String]$MachName,
	[String]$RepFilePath
)
$ErrorActionPreference = "SilentlyContinue"
If ($Error) {
	$Error.Clear()
}
If (Test-Path "$RepFilePath\Error_HyperVClusterReport.txt") {
	Remove-Item "$RepFilePath\Error_HyperVClusterReport.txt"
}
If (Test-Path "$RepFilePath\HyperVClusterReport.txt") {
	Remove-Item "$RepFilePath\HyperVClusterReport.txt"
}
$DT = Get-Date
$Res = Get-WMIObject -NameSpace "Root\CIMV2" -Class "Win32_Service" -ComputerName $MachName | Where-Object {$_.Name -Like 'vmms*' -OR $_.Name -EQ 'vmms'} | Select-Object -Property Status, State
If (!($Error)) {
	If (($Res.Status -IEQ "OK") -AND ($Res.State -IEQ "Running")) {
		$ClusterName = (Get-Cluster -Name $MachName).Name
		If (!($Error) -AND ($ClusterName -NE $Null)) {
			New-Item "$RepFilePath\HyperVClusterReport.txt" -Type File -Force -Value "REPORT: Hyper-V Physical Host Cluster" | Out-Null
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "`n"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "Report Created On $DT"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "============================================================================"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "`n"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "Hyper-V Physical Host $MachName Is Part of a Cluster."
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "Cluster Name: $ClusterName"		
			Get-ClusterNode -Cluster $ClusterName | Select-Object -Property @{Name="ComputerName";Expression={$_.Name}}, @{Name="ClusterState";Expression={$_.State}} | FT -A | Out-File "$RepFilePath\HyperVClusterReport2.txt" 
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "`n`n"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "----------------------------------------------"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "`n`nCluster Node And State Information:"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "----------------------------------------------"
			Add-Content -Path "$RepFilePath\HyperVClusterReport.txt" -Value (Get-Content "$RepFilePath\HyperVClusterReport2.txt")
			Remove-Item "$RepFilePath\HyperVClusterReport2.txt"
			Get-ClusterGroup -Cluster $ClusterName | Select-Object -Property Name, OwnerNode, State, DefaultOwner, AutoFailbackType | FT -A | Out-File "$RepFilePath\HyperVClusterReport2.txt"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "`n`n"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "----------------------------------------------"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "`n`nCluster Group And State Information:"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "----------------------------------------------"
			Add-Content -Path "$RepFilePath\HyperVClusterReport.txt" -Value (Get-Content "$RepFilePath\HyperVClusterReport2.txt")
			Remove-Item "$RepFilePath\HyperVClusterReport2.txt"
			Get-ClusterResource -Cluster $ClusterName | Select-Object -Property Name, OwnerNode, OwnerGroup, State | FT -A | Out-File "$RepFilePath\HyperVClusterReport2.txt"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "`n`n"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "----------------------------------------------"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "`n`nCluster Resource State Information:"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "----------------------------------------------"
			Add-Content -Path "$RepFilePath\HyperVClusterReport.txt" -Value (Get-Content "$RepFilePath\HyperVClusterReport2.txt")
			Remove-Item "$RepFilePath\HyperVClusterReport2.txt"
			Get-ClusterResource -Cluster $ClusterName | Get-ClusterOwnerNode | Select-Object -Property ClusterObject -ExpandProperty OwnerNodes | Select-Object -Property ClusterObject, Name | FT -A | Out-File "$RepFilePath\HyperVClusterReport2.txt"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "`n`n"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "----------------------------------------------"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "`n`nCluster Resource Owner Information:"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "----------------------------------------------"
			Add-Content -Path "$RepFilePath\HyperVClusterReport.txt" -Value (Get-Content "$RepFilePath\HyperVClusterReport2.txt")
			Remove-Item "$RepFilePath\HyperVClusterReport2.txt"
			Get-ClusterNetwork -Cluster $ClusterName | Select-Object -Property Name, Role, Address, State | FT -A | Out-File "$RepFilePath\HyperVClusterReport2.txt"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "`n`n"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "----------------------------------------------"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "`n`nCluster Network State Information:"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "----------------------------------------------"
			Add-Content -Path "$RepFilePath\HyperVClusterReport.txt" -Value (Get-Content "$RepFilePath\HyperVClusterReport2.txt")
			Remove-Item "$RepFilePath\HyperVClusterReport2.txt"
			Get-ClusterNetworkInterface -Cluster $ClusterName | Select-Object -Property Name, Network, Node, State | FT -A | Out-File "$RepFilePath\HyperVClusterReport2.txt"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "`n`n"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "----------------------------------------------"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "`n`nCluster Network Interface Information:"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "----------------------------------------------"
			Add-Content -Path "$RepFilePath\HyperVClusterReport.txt" -Value (Get-Content "$RepFilePath\HyperVClusterReport2.txt")
			Remove-Item "$RepFilePath\HyperVClusterReport2.txt"
			Get-ClusterAccess -Cluster $ClusterName | Select-Object -Property IdentityReference, AccessControlType, ClusterRights | FT -A | Out-File "$RepFilePath\HyperVClusterReport2.txt"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "`n`n"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "----------------------------------------------"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "`n`nCluster Network Interface Information:"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "----------------------------------------------"
			Add-Content -Path "$RepFilePath\HyperVClusterReport.txt" -Value (Get-Content "$RepFilePath\HyperVClusterReport2.txt")
			Remove-Item "$RepFilePath\HyperVClusterReport2.txt"
			Get-ClusterQuorum -Cluster $ClusterName | Select-Object -Property * | FT -A | Out-File "$RepFilePath\HyperVClusterReport2.txt"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "`n`n"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "----------------------------------------------"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "`n`nCluster Quorum Information:"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "----------------------------------------------"
			Add-Content -Path "$RepFilePath\HyperVClusterReport.txt" -Value (Get-Content "$RepFilePath\HyperVClusterReport2.txt")
			Remove-Item "$RepFilePath\HyperVClusterReport2.txt"
			Get-ClusterGroup -Cluster $ClusterName | Get-ClusterResource | Get-ClusterResourceDependency | FT -A | Out-File "$RepFilePath\HyperVClusterReport2.txt"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "`n`n"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "----------------------------------------------"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "`n`nCluster Resource Dependency Information:"
			Add-Content "$RepFilePath\HyperVClusterReport.txt" "----------------------------------------------"
			Add-Content -Path "$RepFilePath\HyperVClusterReport.txt" -Value (Get-Content "$RepFilePath\HyperVClusterReport2.txt")
			Remove-Item "$RepFilePath\HyperVClusterReport2.txt"
		}
		Else {
			If (Test-Path "$RepFilePath\Error_HyperVClusterReport.txt") {
				Add-Content "$RepFilePath\Error_HyperVClusterReport.txt" $Error
				$Error.Clear()
			}
			Else {
				New-Item "$RepFilePath\Error_HyperVClusterReport.txt" -Type File -Force -Value "ERROR REPORT: Hyper-V Physical Host Cluster" | Out-Null
				Add-Content "$RepFilePath\Error_HyperVClusterReport.txt" "`n"
				Add-Content "$RepFilePath\Error_HyperVClusterReport.txt" "Error Report Created On $DT"
				Add-Content "$RepFilePath\Error_HyperVClusterReport.txt" "============================================================================"
				Add-Content "$RepFilePath\Error_HyperVClusterReport.txt" "`n"
				Add-Content "$RepFilePath\Error_HyperVClusterReport.txt" "Encountered An Error On Hyper-V Physical Host Having Computer Name: $MachName"
				Add-Content "$RepFilePath\Error_HyperVClusterReport.txt" $Error
				$Error.Clear()
			}									
		}
	}
}
Else {
	If (!(Test-Path "$RepFilePath\Error_HyperVClusterReport.txt")) {
		New-Item "$RepFilePath\Error_HyperVClusterReport.txt" -Type File -Force -Value "ERROR REPORT: Hyper-V Physical Host Cluster" | Out-Null
		Add-Content "$RepFilePath\Error_HyperVClusterReport.txt" "`n"
		Add-Content "$RepFilePath\Error_HyperVClusterReport.txt" "Error Report Created On $DT"
		Add-Content "$RepFilePath\Error_HyperVClusterReport.txt" "============================================================================"
		Add-Content "$RepFilePath\Error_HyperVClusterReport.txt" "`n"
		Add-Content "$RepFilePath\Error_HyperVClusterReport.txt" "Encountered An Error On Hyper-V Physical Host Having Computer Name: $MachName"
	}
	Add-Content "$RepFilePath\Error_HyperVClusterReport.txt" $Error
	$Error.Clear()
	Add-Content "$RepFilePath\Error_HyperVClusterReport.txt" "Ensure That The Hyper-V Server: $MachName and Hyper-V Services are Up and Running. This Server Cannot Be Contacted At This Time."
	Add-Content "$RepFilePath\Error_HyperVClusterReport.txt" "Ensure That PowerShell Module For Failover Clusters AND Hyper-V Are Properly Installed On This Computer."
	Add-Content "$RepFilePath\Error_HyperVClusterReport.txt" "Ensure That Cluster Services For Failover Clusters On Target Hyper-V Host $MachName Are Up And Working Normally."
}