Param (
	[String]$MachName,
	[String]$Repfile,
	[String]$ErrFile
)

$ErrorActionPreference = "SilentlyContinue"
$DT = Get-Date
If (Test-Path $RepFile) {
	Remove-Item $RepFile
}
If (Test-Path $ErrFile) {
	Remove-Item $ErrFile
}
If ($Error) {
	$Error.Clear()
}

$ChkMe = Get-WMIObject -NameSpace "Root\CIMV2" -Class "Win32_Service" -ComputerName $MachName | Where-Object {$_.Name -IEQ 'vmms'}
If (!($ChkMe) -OR ($ChkMe -EQ $Null)) {
	If (!(Test-Path $ErrFile)) {
		New-Item $ErrFile -Type File -Force -Value "ERROR REPORT: Hyper-V Physical Host $MachName Health Check" | Out-Null
		Add-Content $ErrFile "`n"
		Add-Content $ErrFile "Error Report Created On $DT"
		Add-Content $ErrFile "============================================================================"
		Add-Content $ErrFile "`n"
	}
	Add-Content $ErrFile $Error
	$Error.Clear()
	Add-Content $ErrFile "Ensure That Hyper-V, PowerShell Module For Hyper-V AND Failover Clusters Are Properly Installed On Target Server $MachName."
}
Else {
	## -- Hyper-V Host Details
	Get-VMHost -ComputerName $MachName | Select-Object -Property @{Name="Hyper-VHostName";Expression={$_.ComputerName}}, @{Name="FQDN";Expression={$_.FullyQualifiedDomainName}}, @{Name="Memory(GB)";Expression={$_.MemoryCapacity/1GB -As [Int]}}, @{Name="LogicalProcessor";Expression={$_.LogicalProcessorCount}}, @{Name="MaxStorageMigration";Expression={$_.MaximumStorageMigrations}}, @{Name="MaxVMMigration";Expression={$_.MaximumVirtualMachineMigrations}}, @{Name="VM-MigrationEnabled";Expression={$_.VirtualMachineMigrationEnabled}}, @{Name="NUMA Spanning";Expression={$_.NumaSpanningEnabled}}, @{Name="IOV";Expression={$_.IOVSupport}}, @{Name="EnhancedSessionMode";Expression={$_."EnableEnhancedSessionMode"}}, @{Name="VHDPath";Expression={$_."VirtualHardDiskPath"}}, @{Name="VMPath";Expression={$_."VirtualMachinePath"}} | Export-CSV -Path $RepFile -NoTypeInformation
	Add-Content $RepFile "`n" | Out-Null	

	## -- Hyper-V Host Hardware and Other Details	
	Get-WMIObject -Class "Win32_ComputerSystem" -NameSpace "Root\CIMV2" -ComputerName $MachName | Select Manufacturer, Model, @{Name="TotalMemoryGB";Expression={[Math]::Round(($_.TotalPhysicalMemory/1073741824),2)}}, PartOfDomain, NumberOfProcessors, NumberOfLogicalProcessors | Export-CSV -Path "Temp3.csv" -NoTypeInformation
	Add-Content $RepFile -Value (Get-Content "Temp3.csv")
	Remove-Item "Temp3.csv"
	Add-Content $RepFile "`n" | Out-Null	

	## -- Operating System and Other Details
	Get-WMIObject -Class "Win32_OperatingSystem" -NameSpace "Root\CIMV2" -ComputerName $MachName | Select @{Name="OS";Expression={$_.Caption}}, Manufacturer, OSArchitecture, @{Name="FreeMemory(GB)";Expression={[Math]::Round(($_.FreePhysicalMemory/1MB),2)}}, @{Name="VirtualMemory(GB)";Expression={[Math]::Round(($_.TotalVirtualMemorySize/1MB),2)}}, @{Name="FreeVirtualMemory(GB)";Expression={[Math]::Round(($_.FreeVirtualMemory/1MB),2)}}, @{Name="TotalVisibleMemory(GB)";Expression={[Math]::Round(($_.TotalVisibleMemorySize/1MB),2)}}, @{Name="PercentFree(%)";Expression={[Math]::Round(($_.FreePhysicalMemory/$_.TotalVisibleMemorySize)*100,2)}}, @{LABEL='LastBootUpTime';Expression={$_.ConvertToDateTime($_.LastBootUpTime)}}, Status | Export-CSV -Path "Temp3.csv" -NoTypeInformation

	Add-Content $RepFile -Value (Get-Content "Temp3.csv")
	Remove-Item "Temp3.csv"
	Add-Content $RepFile "`n" | Out-Null	

	## -- Hyper-V Host Network Card Details
	Get-NetAdapterStatistics -CIMSession $MachName | Select Name, @{Name="RcvdUnicastMB";Expression={[Math]::Round(($_.ReceivedUnicastBytes/1MB),2)}}, @{Name="SentUnicastMB";Expression={[Math]::Round(($_.SentUnicastBytes/1MB),2)}}, ReceivedUnicastPackets,SentUnicastPackets, ReceivedDiscardedPackets,OutboundDiscardedPackets | Export-CSV -Path "Temp3.csv" -NoTypeInformation
	Add-Content $RepFile -Value (Get-Content "Temp3.csv")
	Remove-Item "Temp3.csv"
	Add-Content $RepFile "`n" | Out-Null	

	## -- Hyper-V Host Disk and Storage Details
	Get-WMIObject -Class "Win32_LogicalDisk" -NameSpace "Root\CIMV2" -ComputerName $MachName | Where-Object {$_.DriveType -EQ 2 -OR $_.DriveType -EQ 3 -OR $_.DriveType -EQ 4} | Select-Object -Property Name, Description, FileSystem, Compressed, @{Name="Size(GB)";Expression={[Math]::Round(($_.Size/1GB),2)}}, @{Name="Free(GB)";Expression={[Math]::Round(($_.FreeSpace/1GB),2)}}, @{Name="PercentFree(%)";Expression={[Math]::Round(($_.FreeSpace/$_.Size)*100,2)}}, QuotasDisabled, SupportsDiskQuotas, @{Name="SupportsFileCompression";Expression={$_.SupportsFileBasedCompression}}, VolumeDirty, VolumeSerialNumber | Export-CSV -Path "Temp3.csv" -NoTypeInformation
	Add-Content $RepFile -Value (Get-Content "Temp3.csv")
	Remove-Item "Temp3.csv"
	Add-Content $RepFile "`n" | Out-Null	

	## -- Virtual Hard-Disk Check
	$CheckName = $Env:ComputerName.Trim()
	If ($CheckName -IEQ $MachName) {
		Get-VM �ComputerName $MachName | Get-VMHardDiskDrive | Select-Object -Property VMName, ControllerType, ControllerNumber, ControllerLocation, Path, @{Name="VHDPresent";Expression={$_ | Test-Path}} | Export-CSV -Path "Temp3.csv" -NoTypeInformation
	}
	Else {
		Get-VM �ComputerName $MachName | Get-VMHardDiskDrive | Select-Object -Property VMName, ControllerType, ControllerNumber, ControllerLocation, Path, @{Name="VHDPresent";Expression={"Remote VHD"}} | Export-CSV -Path "Temp3.csv" -NoTypeInformation
	}
	Add-Content $RepFile -Value (Get-Content "Temp3.csv")
	Remove-Item "Temp3.csv"
	Add-Content $RepFile "`n" | Out-Null	

	## -- Hyper-V Host Service Details
	Get-WMIObject -Class "Win32_Service" -NameSpace "Root\CIMV2" -ComputerName $MachName | Where-Object {$_.Name -Like 'vmi*' -OR $_.Name -EQ 'vmms'} | Select-Object -Property @{Name="ServiceName";Expression={$_.DisplayName}}, @{Name="ExeName";Expression={$_.Name}}, AcceptStop, PathName, ProcessID, ServiceType, StartMode, Started, @{Name="ServiceAccount";Expression={$_.StartName}}, State, Status | Export-CSV -Path "Temp3.csv" -NoTypeInformation
	Add-Content $RepFile -Value (Get-Content "Temp3.csv")
	Remove-Item "Temp3.csv"
	Add-Content $RepFile "`n" | Out-Null	

	## -- VMs Created In Last 30 Days
	$Res = (Get-VM -ComputerName $MachName | Where-Object CreationTime -GE (Get-Date).AddDays(-30) | Select-Object -Property VMName, State, ReplicationState, ReplicationMode, CPUUsage, MemoryDemand, MemoryAssigned, DynamicMemoryEnabled, IsClustered, Uptime, Status, Path, CreationTime | Measure-Object).Count
	If ($Res -GT 0) {
		Get-VM -ComputerName $MachName | Where-Object CreationTime -GE (Get-Date).AddDays(-30) | Select-Object -Property VMName, State, ReplicationState, ReplicationMode, CPUUsage, MemoryDemand, MemoryAssigned, DynamicMemoryEnabled, IsClustered, Uptime, Status, Path, CreationTime | Export-CSV -Path "Temp3.csv" -NoTypeInformation
		Add-Content $RepFile -Value (Get-Content "Temp3.csv")
		Remove-Item "Temp3.csv"
		Add-Content $RepFile "`n" | Out-Null
	}
}