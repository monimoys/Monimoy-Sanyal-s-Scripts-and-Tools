Param
(
	[String]$HyperHostName,
	[String]$RepFile 
)
$ErrorActionPreference = "SilentlyContinue"
## -- Getting current execution path
$ScriptPath = $MyInvocation.MyCommand.Path
$Dir = Split-Path $ScriptPath
$T = Get-Date
If (Test-Path $RepFile) {
	Remove-Item $RepFile
}
If ($Error) {
	$Error.Clear()
}
New-Item $RepFile -Type File -Force -Value "REPORT: Hyper-V Host $HyperHostName Hyper-V Update Check" | Out-Null
Add-Content $RepFile "`n"
Add-Content $RepFile "Report Created On $T"
Add-Content $RepFile "============================================================================"
Add-Content $RepFile "`n"

Write-Host "`tCurrent Status: Checking For Missing Hyper-V Updates" -ForegroundColor "Yellow"

## -- Loading list of updates from XML files
[xml]$SourceFileHyperV = Get-Content $Dir\UpdatesListHyperV.xml
If ($Error) {
	Add-Content $RepFile "$HyperHostName -- An Error Has Occurred."
	Add-Content $RepFile $Error
	$Error.Clear()
}
$HyperVHotfixes = $SourceFileHyperV.Updates.Update
If ($Error) {
	Add-Content $RepFile "$HyperHostName -- An Error Has Occurred."
	Add-Content $RepFile $Error
	$Error.Clear()
}

## -- Getting Hotfixes installed on the specified Hyper-V Host

ForEach ($VMHost In $HyperHostName) {
	$Hotfixes = Get-HotFix -ComputerName $VMHost | Select HotfixID, Description
	If ($Error) {
		Add-Content $RepFile "$HyperHostName -- An Error Has Occurred."
		Add-Content $RepFile $Error
		$Error.Clear()
	}
	Else {
		Add-Content $RepFile "Hyper-V Server: $HyperHostName"
		Add-Content $RepFile "COLLECTING HOTFIXES ON HYPER-V HOST: $HyperHostName"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "Listing Hyper-V 2012 R2 Hotfixes"
		Add-Content $RepFile "---------------------------------------"
		ForEach ($RecomendedHotfix In $HyperVHotfixes) {
        		$Witness = 0
        		ForEach ($Hotfix In $Hotfixes) {
                		If($RecomendedHotfix.ID -EQ $Hotfix.HotfixID) {
					Add-Content $RepFile "`t$($RecomendedHotfix.Description)" 
                    			Add-Content $RepFile "`t$($RecomendedHotfix.ID) Installed" 
                    			Add-Content $RepFile "`n"
                    			$Witness = 1
                 		}
        		}  
        		If($Witness -EQ 0) {
            			Add-Content $RepFile "`t$($RecomendedHotfix.Description)" 
            			Add-Content $RepFile "`t$($RecomendedHotfix.ID) *** NOT INSTALLED ***" 
            			Add-Content $RepFile "`n"
			}
		}
	}
}