## ==================================================================
## Windows 11 Config Script
## ==================================================================

If ($Error) {$Error.Clear()}
$ErrorActionPreference = "SilentlyContinue"
Write-Host
Write-Host "Working. Please wait ..."
Write-Host
Try {
	Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Scope LocalMachine -Force
	net config server /autodisconnect:-1
	Rename-NetAdapter -Name "Ethernet" -NewName "Local Area Connection" | Out-Null
	Start-Sleep -Seconds 2

	netsh interface set interface name="Local Area Connection" admin=enabled
	netsh interface ip set address "Local Area Connection" static 192.168.20.6 255.255.255.0 192.168.20.1
	netsh interface ip set dns name="Local Area Connection" static 192.168.20.5
	## -- netsh interface ip set address "Local Area Connection" dhcp
	## -- netsh interface ip set dns "Local Area Connection" dhcp
	Start-Sleep -Seconds 2

	Get-NetAdapterBinding -Name "Local Area Connection" | Out-Null
	Disable-NetAdapterBinding -InterfaceAlias "Local Area Connection" -ComponentID "ms_tcpip6" | Out-Null
	Disable-NetAdapterBinding -InterfaceAlias "Local Area Connection" -ComponentID "ms_pacer" | Out-Null
	Disable-NetAdapterBinding -InterfaceAlias "Local Area Connection" -ComponentID "ms_implat" | Out-Null
	Disable-NetAdapterBinding -InterfaceAlias "Local Area Connection" -ComponentID "ms_lldp" | Out-Null
	Disable-NetAdapterBinding -InterfaceAlias "Local Area Connection" -ComponentID "ms_lltdio" | Out-Null
	Disable-NetAdapterBinding -InterfaceAlias "Local Area Connection" -ComponentID "ms_rspndr" | Out-Null

	Get-ScheduledTask -TaskName ServerManager | Disable-ScheduledTask -Verbose
	If (!(Test-Path "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Reliability")) {
		New-Item -Path "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT" -Name "Reliability" -Force | Out-Null
	}	
	Set-WSManQuickConfig -Force

	## -- Enable-PSRemoting -Force
	## -- Enable-PSRemoting -SkipNetworkProfileCheck -Force
	## -- Set-NetFirewallRule -Name 'WINRM-HTTP-In-TCP-PUBLIC' -RemoteAddress Any
	## -- Set-NetFirewallRule -Name "WINRM-HTTP-In-TCP-PUBLIC" -RemoteAddress Any
	## -- netsh advfirewall firewall set rule group="File and Printer Sharing" new enable=Yes
	## -- netsh advfirewall firewall set rule group="remote desktop" new enable=Yes
	## -- netsh advfirewall firewall set rule group="remote desktop" new enable=Yes profile=domain
	## -- netsh advfirewall firewall set rule group="remote desktop" new enable=Yes profile=private
	## -- netsh advfirewall firewall add rule name="ICMP Allow incoming V4 echo request" protocol=icmpv4:8,any dir=in action=allow

	$HPath = Split-Path -Parent $MyInvocation.MyCommand.Definition
	Invoke-Command -FilePath "$HPath\ShowDesktopIcons.ps1" -ComputerName $Env:ComputerName
	Invoke-Item "$HPath\ManPow.cmd"
	# -- Set-DisplayResolution -Width 1024 -Height 768 -Force

	$My_Computer = 17
	$Shell = New-Object -COMObject "Shell.Application"
	$NSComputer = $Shell.Namespace($My_Computer)
	$NSComputer.Self.Name = "My Computer"
	[System.Runtime.InteropServices.Marshal]::ReleaseComObject([System.__ComObject]$Shell) | Out-Null
	Remove-Variable Shell
	[System.GC]::Collect()
	[System.GC]::WaitForPendingFinalizers()

	## -- Write-Host "`n"
	## -- $ThisName = Read-Host "Please Enter New Computer Name: "
	## -- Rename-Computer -ComputerName $Env:ComputerName -NewName $ThisName -Force

	Enable-WindowsOptionalFeature -Online -FeatureName SMB1Protocol -All -NoRestart
	Get-Command reg | Out-Null
	reg import "$HPath\Correct_RegSettingsView.reg"
	reg import "$HPath\DoRegSettings_Others.reg"
}
Catch {
	[System.Exception]
	$ErrorMessage = $_.Exception.Message
    	$FailedItem = $_.Exception.ItemName
	Write-Host "`t Error at $FailedItem. Error message below:" -Foregroundcolor "Cyan"
	Write-Host "`t $ErrorMessage" -Foregroundcolor "Yellow"
}
Finally {
	If ($Error) {$Error.Clear()}
}