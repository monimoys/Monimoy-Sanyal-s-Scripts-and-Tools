Param (
	[String]$RepFile,
	[String]$ErrRepFile
)
If (Test-Path $RepFile) {
	Remove-Item $RepFile
}
If (Test-Path $ErrRepFile) {
	Remove-Item $ErrRepFile
}
$TempRep = "TempReport.txt"
$A = Get-Date
Try {
	Import-Module ActiveDirectory
	$Result = (Get-ADOrganizationalUnit -Filter {(Name -NE "Domain Controllers")} -Properties "msds-approx-immed-subordinates" | where {$_."msds-approx-immed-subordinates" -EQ 0} | Measure-Object).Count
	If ($Result -GT 0) {
		Get-ADOrganizationalUnit -Filter {(Name -NE "Domain Controllers")} -Properties "msds-approx-immed-subordinates" | where {$_."msds-approx-immed-subordinates" -EQ 0} | Sort-Object Name | FT Name, DistinguishedName -A | Out-File $TempRep
		If (Test-Path $RepFile) {
			Remove-Item $RepFile			
		}
		New-Item $RepFile -Type File -Force -value "======================= STATUS REPORT ========================"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "Task --- List of All EMPTY OUs in the Domain. These OUs Can Be Deleted As Part of Clean-Up Job."
		Add-Content $RepFile "`nEMPTY OUs in the Domain Have No Objects Inside Them."
		Add-Content $RepFile "`n"
		Add-Content $RepFile "`nReport Created By OU Manager As On $A"
		Add-Content $RepFile "`nOU Manager Found That The Following Organizational Units in the Domain Are EMPTY"
		Add-Content $RepFile "`n"		
		Add-Content -Path $RepFile -Value (Get-Content $TempRep)
		Remove-Item $TempRep
		Add-Content $RepFile "Total No Of EMPTY Organizational Units: $Result"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "==================== End of STATUS REPORT ===================="
	}
	Else {
		If (Test-Path $RepFile) {
			Remove-Item $RepFile
		}
		New-Item $RepFile -Type File -Force -value "======================= STATUS REPORT ========================"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "Task --- List of All EMPTY OUs in the Domain."
		Add-Content $RepFile "`n"
		Add-Content $RepFile "`n!!GOOD NEWS !!"
		Add-Content $RepFile "`nOU Manager Has Found That There is No EMPTY OU in the Domain."
		Add-Content $RepFile "`nTotal No Of Empty OU in the Domain: $Result"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "==================== End of STATUS REPORT ===================="
	}
}
Catch {
	[System.Exception]
}
Finally {
	If ($Error) {
		If (Test-Path $ErrRepFile) {
			Remove-Item $ErrRepFile
		}
		New-Item $ErrRepFile -Type File -Force -value "======================= Error Log ======================="
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "An Error Occurred While OU Manager Attempted To Create Report About EMPTY OUs in the Domain."
		Add-Content $ErrRepFile "`nInformation in detail is mentioned below:"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`nTask --- Report About All EMPTY OUs in the Domain."
		Add-Content $ErrRepFile $Error
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "==================== End of Error Log ===================="
		$Error.Clear()
	}
}