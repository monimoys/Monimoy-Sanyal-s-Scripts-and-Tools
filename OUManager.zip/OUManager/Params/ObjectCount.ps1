Param(
	[String]$OUPath,
	[String]$RepFile
)
$A = Get-Date
If (Test-Path $RepFile) {
	Remove-Item $RepFile
}
New-Item $RepFile -Type File -Force -value "======================= STATUS REPORT Created By OU Manager ========================"
Add-Content $RepFile "`n"
Add-Content $RepFile "`n"
Add-Content $RepFile "Task --- Report All Objects Inside The Selected Domain OU"
Add-Content $RepFile "`nSelected OU --- $OUPath"
Add-Content $RepFile "`n"
Add-Content $RepFile "Report Created On $A"
Add-Content $RepFile "`n"
Add-Content $RepFile "SUMMARY -- OU Manager Found the Following Objects Inside the Selected OU"
Add-Content $RepFile "`n-----------------------------------------------------------------------------"
Add-Content $RepFile "`n"

Import-Module ActiveDirectory

$ChildResult = (Get-ADObject -Filter {(ObjectClass -EQ "OrganizationalUnit") -AND (ObjectCategory -EQ "OrganizationalUnit")} -SearchBase $OUPath -SearchScope OneLevel -Properties Name | Measure-Object).Count
Add-Content $RepFile "Total Number Of Child OUs Inside The Selected OU -- $ChildResult"

$UserCount = (Get-ADObject -Filter {(ObjectClass -EQ "User") -AND (ObjectCategory -EQ "User") -AND (SAMAccountName -NotLike "*$")} -SearchBase $OUPath -SearchScope OneLevel -Properties DistinguishedName | Measure-Object).Count
Add-Content $RepFile "Total Number Of AD User-Accounts Inside The Selected OU -- $UserCount"

$CompCount = (Get-ADObject -Filter {(ObjectClass -EQ "Computer") -AND (ObjectCategory -EQ "Computer")} -SearchBase $OUPath -SearchScope OneLevel -Properties DistinguishedName | Measure-Object).Count
Add-Content $RepFile "Total Number Of AD Computer Objects Inside The Selected OU -- $CompCount"

$GRPCount = (Get-ADObject -Filter {(ObjectClass -EQ "Group")} -SearchBase $OUPath -SearchScope OneLevel -Properties Name | Measure-Object).Count
Add-Content $RepFile "Total Number Of AD Groups Inside The Selected OU -- $GRPCount"

Add-Content $RepFile "`n"

If ($ChildResult -GT 0) {
	Add-Content $RepFile "List of All Child OUs Inside The Selected OU -- $OUPath"
	Add-Content $RepFile "`n-------------------------------------------------------------------------------------------------------------"
	Get-ADObject -Filter {(ObjectClass -EQ "OrganizationalUnit") -AND (ObjectCategory -EQ "OrganizationalUnit")} -SearchBase $OUPath -SearchScope OneLevel -Properties Name, DistinguishedName | Sort-Object Name | FT Name, DistinguishedName -A | Out-File "Temp2.txt"
	# Add-Content $RepFile "`n"
	Add-Content -Path $RepFile -Value (Get-Content "Temp2.txt")
	Remove-Item "Temp2.txt"
}

If ($UserCount -GT 0) {
	Add-Content $RepFile "List of All AD User Accounts Inside The Selected OU -- $OUPath"
	Add-Content $RepFile "`n-------------------------------------------------------------------------------------------------------------"
	Get-ADObject -Filter {(ObjectClass -EQ "User") -AND (ObjectCategory -EQ "User") -AND (SAMAccountName -NotLike "*$")} -SearchBase $OUPath -SearchScope OneLevel -Properties SAMAccountName, DisplayName, UserPrincipalName, DistinguishedName | Sort-Object SAMAccountName | FT SAMAccountName, DisplayName, UserPrincipalName, DistinguishedName -A | Out-File "Temp2.txt"
	# Add-Content $RepFile "`n"
	Add-Content -Path $RepFile -Value (Get-Content "Temp2.txt")
	Remove-Item "Temp2.txt"
}

If ($CompCount -GT 0) {
	Add-Content $RepFile "List of All AD Computer Objects Inside The Selected OU -- $OUPath"
	Add-Content $RepFile "`n-------------------------------------------------------------------------------------------------------------"
	Get-ADObject -Filter {(ObjectClass -EQ "Computer") -AND (ObjectCategory -EQ "Computer")} -SearchBase $OUPath -SearchScope OneLevel -Properties Name, DistinguishedName | Sort-Object Name | FT Name, DistinguishedName -A | Out-File "Temp2.txt"
	# Add-Content $RepFile "`n"
	Add-Content -Path $RepFile -Value (Get-Content "Temp2.txt")
	Remove-Item "Temp2.txt"
}

If ($GRPCount -GT 0) {
	Add-Content $RepFile "List of All AD GROUPS Inside The Selected OU -- $OUPath"
	Add-Content $RepFile "`n-------------------------------------------------------------------------------------------------------------"
	Get-ADObject -Filter {(ObjectClass -EQ "Group") -AND (ObjectCategory -EQ "Group")} -SearchBase $OUPath -SearchScope OneLevel -Properties Name, DistinguishedName, WhenCreated | Sort-Object Name | FT Name, DistinguishedName, WhenCreated -A | Out-File "Temp2.txt"
	# Add-Content $RepFile "`n"
	Add-Content -Path $RepFile -Value (Get-Content "Temp2.txt")
	Remove-Item "Temp2.txt"
}

Add-Content $RepFile "==================== End of STATUS REPORT ===================="