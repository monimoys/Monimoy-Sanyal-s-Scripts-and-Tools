Param(
	[String]$OUPath,
	[String]$RepFile
)

$A = Get-Date

If (Test-Path $RepFile) {
	Remove-Item $RepFile
}

Import-Module ActiveDirectory

$Result = (Get-ADObject -Filter {ObjectClass -Like "*"} -SearchBase $OUPath -SearchScope OneLevel -Properties ProtectedFromAccidentalDeletion | where {$_.ProtectedFromAccidentalDeletion -EQ $True} | Measure-Object).Count
If ($Result -GT 0) {
	Get-ADObject -Filter {ObjectClass -Like "*"} -SearchBase $OUPath -SearchScope OneLevel -Properties ProtectedFromAccidentalDeletion | where {$_.ProtectedFromAccidentalDeletion -EQ $True}| Sort-Object ObjectClass | FT ObjectClass, Name, DistinguishedName -A | Out-File "Temp2.txt"
	New-Item $RepFile -Type File -Force -value "======================= STATUS REPORT ========================"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "Task --- List of All PROTECTED OBJECTS Inside Selected Domain OU"
	Add-Content $RepFile "`nSelected OU: $OUPath"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`nReport Created By OU Manager As On $A"
	Add-Content $RepFile "`nOU Manager Found That The Following AD Objects Inside The Selected OU Are Protected From Deletion"
	Add-Content $RepFile "`n"		
	Add-Content -Path $RepFile -Value (Get-Content "Temp2.txt")
	Remove-Item "Temp2.txt"
	Add-Content $RepFile "Total No Of Protected AD Objects : $Result"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "==================== End of STATUS REPORT ===================="	
}
Else {
	New-Item $RepFile -Type File -Force -value "======================= STATUS REPORT ========================"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "Task --- List of All PROTECTED OBJECTS Inside Selected Domain OU"
	Add-Content $RepFile "`nSelected OU: $OUPath"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`nReport Created By OU Manager As On $A"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`n!!! CAUTION !!!"
	Add-Content $RepFile "`nOU Manager Found That NO AD Object Inside The Selected OU IS PROTECTED From Deletion."
	Add-Content $RepFile "`nAdministrator SHOULD take note of this and take appropriate action."
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`nTotal No Of Protected AD Objects : $Result"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "==================== End of STATUS REPORT ===================="		
}
