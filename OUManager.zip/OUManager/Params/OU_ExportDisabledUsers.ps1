Param (
	[String]$OUPath,
	[String]$RepFile,
	[String]$ErrRepFile
)
If (Test-Path $RepFile) {
	Remove-Item $RepFile
}

$A = Get-Date

Try {
	Import-Module ActiveDirectory
	$Result = (Search-ADAccount -SearchBase $OUPath -AccountDisabled -UsersOnly | Measure-Object).Count
	If ($Result -GT 0) {
		Search-ADAccount -SearchBase $OuPath -AccountDisabled -UsersOnly | Sort-Object SAMAccountName | FT SAMAccountName, ObjectClass, Enabled, DistinguishedName -A | Out-File "Temp2.txt"
		If (Test-Path $RepFile) {
			Remove-Item $RepFile			
		}
		New-Item $RepFile -Type File -Force -value "======================= OU MANAGER STATUS REPORT ========================"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "Task --- List of All DISABLED USER ACCOUNTS In Selected OU"
		Add-Content $RepFile "`nSelected OU -- $OUPath"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "`nReport Created By OU Manager As On $A"
		Add-Content $RepFile "`nOU Manager Found That The Following User Accounts Inside Selected OU Are DISABLED:"
		Add-Content $RepFile "`n"		
		Add-Content -Path $RepFile -Value (Get-Content "Temp2.txt")
		Remove-Item "Temp2.txt"
		Add-Content $RepFile "`nTotal No Of DISABLED USER ACCOUNTS -- $Result"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "==================== End of STATUS REPORT ===================="
	}
	Else {
		If (Test-Path $RepFile) {
			Remove-Item $RepFile
		}
		New-Item $RepFile -Type File -Force -value "======================= OU MANAGER STATUS REPORT ========================"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "Task --- List of All DISABLED USER ACCOUNTS In Selected OU"
		Add-Content $RepFile "`nSelected OU -- $OUPath"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "`nReport Created By OU Manager As On $A"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "`nOU Manager Found That There Is No DISABLED USER ACCOUNT Inside Selected OU."
		Add-Content $RepFile "`nTotal No Of DISABLED USER Accounts -- $Result"
		Add-Content $RepFile "`nDomain Administrator SHOULD note this information and take appropriate action."
		Add-Content $RepFile "`n"
		Add-Content $RepFile "==================== End of STATUS REPORT ===================="
	}
}
Catch {
	[System.Exception]
}
Finally {
	If ($Error) {
		If (Test-Path $ErrRepFile) {
			Remove-Item $ErrRepFile
		}
		New-Item $ErrRepFile -Type File -Force -value "======================= OU MANAGER ERROR LOG ======================="
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`n"
		Add-Content $RepFile "Task --- List of All DISABLED USER ACCOUNTS Inside Selected OU"
		Add-Content $RepFile "`nSelected OU -- $OUPath"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "An Error Occurred While OU Manager Attempted To Report All DISABLED User Accounts Inside Selected OU."		
		Add-Content $ErrRepFile "`nInformation in detail is mentioned below:"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile $Error
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "==================== End of Error Log ===================="
		$Error.Clear()
	}
}