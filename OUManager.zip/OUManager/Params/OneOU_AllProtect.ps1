Param (
	[String]$OUPath,
	[String]$ErrRepFile
)

$A = Get-Date
If (Test-Path $ErrRepFile) {
	Remove-Item $ErrRepFile
}

Try {
	Import-Module ActiveDirectory
	Get-ADObject -Filter {(ObjectClass -Like "*") -AND (ObjectCategory -Like "*")} -SearchBase $OUPath -SearchScope OneLevel -Properties ProtectedFromAccidentalDeletion | Where {$_.ProtectedFromAccidentalDeletion -EQ $False} | Set-ADObject -ProtectedFromAccidentalDeletion $True
}
Catch {
	[System.Exception]
}
Finally {
	If ($Error) {
		If (Test-Path $ErrRepFile) {
			Remove-Item $ErrRepFile
		}
		New-Item $ErrRepFile -Type File -Force -value "======================== OU MANAGER ERROR LOG ========================"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "An Error Occurred While OU Manager Attempted To Protect All Objects Inside Selected OU From Deletion"
		Add-Content $ErrRepFile "`nSelected OU -- $OUPath"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`nError Report Created On: $A"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`nInformation in detail is mentioned below:"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile $Error
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "===================== End of Error Log ====================="
		$Error.Clear()
	}
}




