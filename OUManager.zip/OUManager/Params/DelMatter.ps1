Param (
	[String]$OUPath,
	[String]$ErrRepFile
)
If (Test-Path $ErrRepFile) {
	Remove-Item $ErrRepFile
}
$A = Get-Date
Try {
	Import-Module ActiveDirectory
	Remove-ADOrganizationalUnit -Identity $OUPath -Recursive -Confirm:$False
}
Catch {
	[System.Exception]
}
Finally {
	If ($Error) {
		If (Test-Path $ErrRepFile) {
			Remove-Item $ErrRepFile
		}
		New-Item $ErrRepFile -Type File -Force -value "======================== OU MANAGER ERROR LOG ========================"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "An Error Occurred While OU Manager Attempted To DELETE Selected Organizational Unit"
		Add-Content $ErrRepFile "`nSelected OU -- $OUPath"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`nError Report Created On: $A"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`nInformation in detail is mentioned below:"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile $Error
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "===================== End of Error Log ====================="
		$Error.Clear()
	}
}
