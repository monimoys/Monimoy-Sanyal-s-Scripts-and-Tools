Param (
	[String]$ErrRepFile,
	[String]$StatRepFile
)
If (Test-Path $ErrRepFile) {
	Remove-Item $ErrRepFile
}
If (Test-Path $StatRepFile) {
	Remove-Item $StatRepFile
}
Try{
	Import-Module ActiveDirectory
	$Result = (Get-ADOrganizationalUnit -Filter {(Name -NE "Domain Controllers")} -Properties ProtectedFromAccidentalDeletion | where {$_.ProtectedFromAccidentalDeletion -EQ $False} | Measure-Object).Count
	If ($Result -GT 0) {
		Get-ADOrganizationalUnit -Filter {(Name -NE "Domain Controllers")} -Properties ProtectedFromAccidentalDeletion | where {$_.ProtectedFromAccidentalDeletion -EQ $False} | Set-ADOrganizationalUnit -ProtectedFromAccidentalDeletion $True
	}
	Else {
		If (Test-Path $StatRepFile) {
			Remove-Item $StatRepFile
		}
		New-Item $StatRepFile -Type File -Force -value "======================= STATUS REPORT ========================"
		Add-Content $StatRepFile "`n"
		Add-Content $StatRepFile "`n"
		Add-Content $StatRepFile "Task --- Protect All OUs From Accidental Deletion"
		Add-Content $StatRepFile "`n"
		Add-Content $StatRepFile "`n!!Good NEWS !!"
		Add-Content $StatRepFile "`nOU Manager Found That All Organizational Units in the Domain Are Already Protected From Deletion"
		Add-Content $StatRepFile "`nHence, No Action Has Been Performed By OU Manager."
		Add-Content $StatRepFile "`n"
		Add-Content $StatRepFile "==================== End of STATUS REPORT ===================="
	}
}
Catch {
	[System.Exception]
}
Finally {
	If ($Error) {
		If (Test-Path $ErrRepFile) {
			Remove-Item $ErrRepFile
		}
		New-Item $ErrRepFile -Type File -Force -value "======================= Error Log ======================="
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "An Error Occurred While OU Manager Attempted To Protect All Organizational Units From Accidental Deletion"
		Add-Content $ErrRepFile "`nInformation in detail is mentioned below:"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`nTask --- Protect All OUs From Accidental Deletion"
		Add-Content $ErrRepFile $Error
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "==================== End of Error Log ===================="
		$Error.Clear()
	}
}