Param (
	$RepFile
)

$A = Get-Date
If (Test-Path $RepFile) {
	Remove-Item $RepFile
}

Try {
	New-Item $RepFile -Type File -Force -value "=========================== OU MANAGER SYSTEM INFO REPORT ============================"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "OU Manager Generated The Following Information About The Computer On Which It Is Currently Running"
	Add-Content $RepFile "`nReport Generated On $A"
	Add-Content $RepFile "`n-------------------------------------------------------------------------------------------------------------------"
	Add-Content $RepFile "`n"
	SystemInfo | Out-File "Rep2.txt"
	Add-Content -Path $RepFile -Value (Get-Content "Rep2.txt")
	Remove-Item "Rep2.txt"
	Add-Content $RepFile "`n"
	Add-Content $RepFile "================================= END OF REPORT ================================="
}
Catch {
	[System.Exception]
}
Finally {
	If ($Error) {
		If (Test-Path $RepFile) {
			Remove-Item $RepFile
		}
		New-Item $RepFile -Type File -Force -value "=========================== OU MANAGER SYSTEM INFO REPORT ============================"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "OU Manager Encountered An Error While Attempting To Generate The System Information Report"
		Add-Content $RepFile "`nReport Generated On $A"
		Add-Content $RepFile "`n-------------------------------------------------------------------------------------------------------------------"
		Add-Content $RepFile "`n"
		Add-Content $RepFile $Error
		Add-Content $RepFile "`n"
		Add-Content $RepFile "==================== End of Error Log ===================="
		$Error.Clear()
	}
}