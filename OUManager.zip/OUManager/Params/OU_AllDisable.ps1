Param (
	[String]$RepFileComp,
	[String]$RepFileUser,
	[String]$ErrRepFile
)
If (Test-Path $RepFileComp) {
	Remove-Item $RepFileComp
}
If (Test-Path $RepFileUser) {
	Remove-Item $RepFileUser
}
If (Test-Path $ErrRepFile) {
	Remove-Item $ErrRepFile
}

$A = Get-Date

Try {
	Import-Module ActiveDirectory
	$StrDom = Get-ADDomain | Select -ExpandProperty DistinguishedName
	If ($StrDom -NE $null) {
		$Result = (Search-ADAccount -SearchBase $StrDom -AccountDisabled -ComputersOnly | Measure-Object).Count
		If ($Result -GT 0) {
			Search-ADAccount -SearchBase $StrDom -AccountDisabled -ComputersOnly | Sort-Object Name | FT Name, ObjectClass, Enabled, DistinguishedName -A | Out-File "Temp2.txt"
			If (Test-Path $RepFileComp) {
				Remove-Item $RepFileComp			
			}
			New-Item $RepFileComp -Type File -Force -value "======================= OU MANAGER STATUS REPORT ========================"
			Add-Content $RepFileComp "`n"
			Add-Content $RepFileComp "`n"
			Add-Content $RepFileComp "Task --- List of All DISABLED COMPUTER ACCOUNTS In Domain $StrDom"
			Add-Content $RepFileComp "`n"
			Add-Content $RepFileComp "`nReport Created By OU Manager As On $A"
			Add-Content $RepFileComp "`nOU Manager Found That The Following Computer Accounts Are DISABLED in the Domain"
			Add-Content $RepFileComp "`n"		
			Add-Content -Path $RepFileComp -Value (Get-Content "Temp2.txt")
			Remove-Item "Temp2.txt"
			Add-Content $RepFileComp "`nTotal No Of DISABLED COMPUTER ACCOUNTS -- $Result"
			Add-Content $RepFileComp "`n"
			Add-Content $RepFileComp "==================== End of STATUS REPORT ===================="
		}
		Else {
			If (Test-Path $RepFileComp) {
				Remove-Item $RepFileComp
			}
			New-Item $RepFileComp -Type File -Force -value "======================= OU MANAGER STATUS REPORT ========================"
			Add-Content $RepFileComp "`n"
			Add-Content $RepFileComp "`n"
			Add-Content $RepFileComp "Task --- List of All DISABLED COMPUTER ACCOUNTS In Domain $StrDom"
			Add-Content $RepFileComp "`n"
			Add-Content $RepFileComp "`nReport Created By OU Manager As On $A"
			Add-Content $RepFileComp "`n"
			Add-Content $RepFileComp "`nOU Manager Found That There Is No DISABLED COMPUTER ACCOUNT in the Domain."
			Add-Content $RepFileComp "`nTotal No Of DISABLED COMPUTER Accounts -- $Result"
			Add-Content $RepFileComp "`nDomain Administrator SHOULD note this information and take appropriate action."
			Add-Content $RepFileComp "`n"
			Add-Content $RepFileComp "==================== End of STATUS REPORT ===================="
		}
		
		$Result = (Search-ADAccount -SearchBase $StrDom -AccountDisabled -UsersOnly | Measure-Object).Count
		If ($Result -GT 0) {
			Search-ADAccount -SearchBase $StrDom -AccountDisabled -UsersOnly | Sort-Object SAMAccountName | FT SAMAccountName, ObjectClass, Enabled, DistinguishedName -A | Out-File "Temp2.txt"
			If (Test-Path $RepFileUser) {
				Remove-Item $RepFileUser			
			}
			New-Item $RepFileUser -Type File -Force -value "======================= OU MANAGER STATUS REPORT ========================"
			Add-Content $RepFileUser "`n"
			Add-Content $RepFileUser "`n"
			Add-Content $RepFileUser "Task --- List of All DISABLED USER ACCOUNTS In Domain $StrDom"
			Add-Content $RepFileUser "`n"
			Add-Content $RepFileUser "`nReport Created By OU Manager As On $A"
			Add-Content $RepFileUser "`nOU Manager Found That The Following User Accounts Are DISABLED in the Domain"
			Add-Content $RepFileUser "`n"		
			Add-Content -Path $RepFileUser -Value (Get-Content "Temp2.txt")
			Remove-Item "Temp2.txt"
			Add-Content $RepFileUser "`nTotal No Of DISABLED USER ACCOUNTS -- $Result"
			Add-Content $RepFileUser "`n"
			Add-Content $RepFileUser "==================== End of STATUS REPORT ===================="
		}
		Else {
			If (Test-Path $RepFileUser) {
				Remove-Item $RepFileUser
			}
			New-Item $RepFileUser -Type File -Force -value "======================= OU MANAGER STATUS REPORT ========================"
			Add-Content $RepFileUser "`n"
			Add-Content $RepFileUser "`n"
			Add-Content $RepFileUser "Task --- List of All DISABLED USER ACCOUNTS In Domain $StrDom"
			Add-Content $RepFileUser "`n"
			Add-Content $RepFileUser "`nReport Created By OU Manager As On $A"
			Add-Content $RepFileUser "`n"
			Add-Content $RepFileUser "`nOU Manager Found That There Is No DISABLED USER ACCOUNT in the Domain."
			Add-Content $RepFileUser "`nTotal No Of DISABLED USER Accounts -- $Result"
			Add-Content $RepFileUser "`nDomain Administrator SHOULD note this information and take appropriate action."
			Add-Content $RepFileUser "`n"
			Add-Content $RepFileUser "==================== End of STATUS REPORT ===================="
		}
	}
}
Catch {
	[System.Exception]
}
Finally {
	If ($Error) {
		If (Test-Path $ErrRepFile) {
			Remove-Item $ErrRepFile
		}
		New-Item $ErrRepFile -Type File -Force -value "======================= OU MANAGER ERROR LOG ======================="
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`n"
		Add-Content $RepFile "Task --- List of All DISABLED ACCOUNTS In Domain $StrDom"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "An Error Occurred While OU Manager Attempted To Report All DISABLED Accounts In The Domain."		
		Add-Content $ErrRepFile "`nInformation in detail is mentioned below:"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile $Error
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "==================== End of Error Log ===================="
		$Error.Clear()
	}
}