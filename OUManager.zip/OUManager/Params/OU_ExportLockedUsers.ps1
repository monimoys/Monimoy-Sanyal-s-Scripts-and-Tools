Param (
	[String]$OUPath,
	[String]$RepFile,
	[String]$ErrRepFile
)
If (Test-Path $RepFile) {
	Remove-Item $RepFile
}
If (Test-Path $ErrRepFile) {
	Remove-Item $ErrRepFile
}

$A = Get-Date

Try {
	Import-Module ActiveDirectory
	$Result = (Search-ADAccount -SearchBase $OUPath -LockedOut | Measure-Object).Count
	If ($Result -GT 0) {
		Search-ADAccount -SearchBase $OUPath -LockedOut | Sort-Object SAMAccountName | FT ObjectClass, SAMAccountName, LockedOut, DistinguishedName -A | Out-File "Temp2.txt"
		If (Test-Path $RepFile) {
			Remove-Item $RepFile			
		}
		New-Item $RepFile -Type File -Force -value "======================= OU MANAGER STATUS REPORT ========================"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "Task --- List of All LOCKED-OUT ACCOUNTS Inside Selected OU"
		Add-Content $RepFile "`nSelected OU -- $OUPath"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "`nReport Created By OU Manager As On $A"
		Add-Content $RepFile "`nOU Manager Found That The Following Accounts Are LOCKED-OUT Inside Selected OU:"
		Add-Content $RepFile "`n"		
		Add-Content -Path $RepFile -Value (Get-Content "Temp2.txt")
		Remove-Item "Temp2.txt"
		Add-Content $RepFile "Total No Of LOCKED-OUT Accounts -- $Result"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "==================== End of STATUS REPORT ===================="
	}
	Else {
		If (Test-Path $RepFile) {
			Remove-Item $RepFile
		}
		New-Item $RepFile -Type File -Force -value "======================= OU MANAGER STATUS REPORT ========================"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "Task --- List of All LOCKED-OUT ACCOUNTS Inside Selected OU"
		Add-Content $RepFile "`nSelected OU -- $OUPath"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "`nReport Created By OU Manager As On $A"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "`nOU Manager Found That There Is No LOCKED-OUT ACCOUNT Inside Selected OU."
		Add-Content $RepFile "`nTotal No Of LOCKED-OUT Accounts -- $Result"
		Add-Content $RepFile "`nDomain Administrator SHOULD note this information and take appropriate action."
		Add-Content $RepFile "`n"
		Add-Content $RepFile "==================== End of STATUS REPORT ===================="
	}
}
Catch {
	[System.Exception]
}
Finally {
	If ($Error) {
		If (Test-Path $ErrRepFile) {
			Remove-Item $ErrRepFile
		}
		New-Item $ErrRepFile -Type File -Force -value "======================= OU MANAGER ERROR LOG ======================="
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`n"
		Add-Content $RepFile "Task --- List of All LOCKED-OUT ACCOUNTS Inside Selected OU"
		Add-Content $RepFile "`nSelected OU -- $OUPath"
		Add-Content $ErrRepFile "`n"
		Add-Content $RepFile "`nReport Created By OU Manager As On $A"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`nAn Error Occurred While OU Manager Attempted To Report All LOCKED-OUT Accounts Inside Selected OU."		
		Add-Content $ErrRepFile "`nInformation in detail is mentioned below:"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile $Error
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "==================== End of Error Log ===================="
		$Error.Clear()
	}
}