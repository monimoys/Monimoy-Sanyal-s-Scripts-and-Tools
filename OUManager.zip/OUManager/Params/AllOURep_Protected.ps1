Param (
	[String]$RepFileName,
	[String]$ErrRepFile
)
If (Test-Path $RepFileName) {
	Remove-Item $RepFileName
}
$TempRep = "TempResult.txt"
$A = Get-Date
Try {
	Import-Module ActiveDirectory
	$Result = (Get-ADOrganizationalUnit -Filter {(Name -NE "Domain Controllers")} -Properties ProtectedFromAccidentalDeletion | where {$_.ProtectedFromAccidentalDeletion -eq $True} | Measure-Object).Count
	If ($Result -GT 0) {
		Get-ADOrganizationalUnit -Filter {(Name -NE "Domain Controllers")} -Properties ProtectedFromAccidentalDeletion | where {$_.ProtectedFromAccidentalDeletion -eq $True} | Select @{Name="OU Name";Expression={$_."Name"}}, DistinguishedName, @{Name="Protected";Expression={$_."ProtectedFromAccidentalDeletion"}} | Sort-Object "OU Name" | FT "OU Name", Protected, DistinguishedName -A | Out-File $TempRep
		If (Test-Path $RepFileName) {
			Remove-Item $RepFileName			
		}
		New-Item $RepFileName -Type File -Force -value "======================= STATUS REPORT ========================"
		Add-Content $RepFileName "`n"
		Add-Content $RepFileName "`n"
		Add-Content $RepFileName "Task --- List of All Domain OUs PROTECTED From Deletion"
		Add-Content $RepFileName "`n"
		Add-Content $RepFileName "`nReport Created By OU Manager As On $A"
		Add-Content $RepFileName "`nOU Manager Found That The Following Organizational Units in the Domain Are Protected From Deletion"
		Add-Content $RepFileName "`n"		
		Add-Content -Path $RepFileName -Value (Get-Content $TempRep)
		Remove-Item $TempRep
		Add-Content $RepFileName "Total No Of Protected Organizational Units: $Result"
		Add-Content $RepFileName "`n"
		Add-Content $RepFileName "==================== End of STATUS REPORT ===================="
	}
	Else {
		If (Test-Path $RepFileName) {
			Remove-Item $RepFileName
		}
		New-Item $RepFileName -Type File -Force -value "======================= STATUS REPORT ========================"
		Add-Content $RepFileName "`n"
		Add-Content $RepFileName "`n"
		Add-Content $RepFileName "Task --- List of All Domain OUs PROTECTED From Deletion"
		Add-Content $RepFileName "`n"
		Add-Content $RepFileName "`n!!CAUTION !!"
		Add-Content $RepFileName "`nOU Manager Found That No Organizational Unit in the Domain is Protected From Deletion"
		Add-Content $RepFileName "`nDomain Administrator SHOULD note this information and take appropriate action."
		Add-Content $RepFileName "`n"
		Add-Content $RepFileName "==================== End of STATUS REPORT ===================="
	}
}
Catch {
	[System.Exception]
}
Finally {
	If ($Error) {
		If (Test-Path $ErrRepFile) {
			Remove-Item $ErrRepFile
		}
		New-Item $ErrRepFile -Type File -Force -value "======================= Error Log ======================="
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "An Error Occurred While OU Manager Attempted To Create Report About All Domain OUs PROTECTED From Deletion"
		Add-Content $ErrRepFile "`nInformation in detail is mentioned below:"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`nTask --- Report About All Domain OUs PROTECTED From Deletion"
		Add-Content $ErrRepFile $Error
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "==================== End of Error Log ===================="
		$Error.Clear()
	}
}
