Param (
	[String]$OUName,
	[String]$OUPath,
	[String]$RepFile,
	[String]$ErrRepFile
)

If (Test-Path $RepFile) {
	Remove-Item $RepFile
}
If (Test-Path $ErrRepFile) {
	Remove-Item $ErrRepFile
}

Try {
	Import-Module ActiveDirectory
	New-ADOrganizationalUnit -Name $OUName -Path $OUPath -ProtectedFromAccidentalDeletion $False -OtherAttributes @{Description="Created with OU Manager";DisplayName=$OUName}
}
Catch {
	[System.Exception]
}
Finally {
	If ($Error) {
		New-Item $ErrRepFile -Type File -Force -value "========================= START ERROR LOG ========================="
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "Selected Task: Create New Child OU Inside Selected OU -- $OUPath"
		Add-Content $ErrRepFile "`nOU Manager Encountered Error While Executing The Above Task"
		Add-Content $ErrRepFile "`nNew Child OU Has NOT BEEN CREATED. Detailed Error Message Is Mentioned Below:"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile $Error
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "========================= END ERROR LOG ========================="
		$Error.Clear()
	}
	Else {
		$A = Get-Date
		New-Item $RepFile -Type File -Force -value "========================= START OU MANAGER REPORT ========================="
		Add-Content $RepFile "`n"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "Selected Task: Create New Child OU Inside Selected OU -- $OUPath"
		Add-Content $RepFile "`nNew Child OU Name: $OUName"
		Add-Content $RepFile "`nNew Child OU Has Been SUCCESSFULLY CREATED."
		Add-Content $RepFile "`nObject Creation Date and Time: $A"
		Add-Content $RepFile "`n"
		Add-Content $RepFile "========================= END OU MANAGER REPORT ========================="
	}
}
