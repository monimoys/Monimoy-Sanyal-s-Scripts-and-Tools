Param (
	$SourceOU,
	$DestOu,
	$ErrRepFile
)

$A = Get-Date
If (Test-Path $ErrRepFile) {
	Remove-Item $ErrRepFile
}

Try {
	Import-Module ActiveDirectory
	$Result = (Get-ADObject -Filter {(ObjectClass -EQ "Group")} -Searchbase $SourceOU -SearchScope OneLevel -Properties DistinguishedName | Measure-Object).Count
	If ($Result -GT 0) {
		Get-ADObject -Filter {(ObjectClass -EQ "Group")} -Searchbase $SourceOU -SearchScope OneLevel | Move-ADObject -TargetPath $DestOU
	}
	Else {
		If (Test-Path $ErrRepFile) {
			Remove-Item $ErrRepFile
		}
		New-Item $ErrRepFile -Type File -Force -value "=========================== OU MANAGER STATUS REPORT ============================"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "An Error Occurred While OU Manager Attempted To Move Objects From One OU To Another OU"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`Source OU -- $SourceOU"
		Add-Content $ErrRepFile "`nTarget OU -- $DestOU"
		Add-Content $ErrRepFile "`nObjects To Move -- All Active Directory GROUPS"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`nReport Generated On: $A"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`nInformation in detail is mentioned below:"
		Add-Content $ErrRepFile "`n-----------------------------------------------"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "There is No Active Directory GROUP Inside The Source OU To Move To The Target OU."
		Add-Content $ErrRepFile "`nOU Manager Did Not Move Anything From Source OU To Target OU."
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "============================ End of Status Report ============================"
	}
}
Catch {
	[System.Exception]
}
Finally {
	If ($Error) {
		If (Test-Path $ErrRepFile) {
			Remove-Item $ErrRepFile
		}
		New-Item $ErrRepFile -Type File -Force -value "======================= Error Log ======================="
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "An Error Occurred While OU Manager Attempted To Move Objects From One OU To Another OU"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`Source OU -- $SourceOU"
		Add-Content $ErrRepFile "`nTarget OU -- $DestOU"
		Add-Content $ErrRepFile "`nObjects To Move -- All Active Directory GROUPS"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`nReport Generated On: $A"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`nInformation in detail is mentioned below:"
		Add-Content $ErrRepFile "`n-----------------------------------------------"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile $Error
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "==================== End of Error Log ===================="
		$Error.Clear()
	}
}