Param (
	[String]$OUPath,
	[String]$RemScope,
	[String]$ErrRepFile
)

If (Test-Path $ErrRepFile) {
	Remove-Item $ErrRepFile
}

Try {
	Import-Module ActiveDirectory
	Import-Module GroupPolicy
	If ($RemScope -EQ "All") {
		(Get-GPInheritance -Target $OUPath).GpoLinks | Remove-GPLink
	}
	Else {
		Remove-GPLink -Name $RemScope -Target $OUPath
	}
}
Catch {
	[System.Exception]
}
Finally {
	If ($Error) {
		If (Test-Path $ErrRepFile) {
			Remove-Item $ErrRepFile
		}
		New-Item $ErrRepFile -Type File -Force -value "======================= OU MANAGER ERROR LOG ======================="
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "An Error Occurred While OU Manager Attempted To Un-Link GPOs From Domain OU"
		Add-Content $ErrRepFile "Selected OU -- $OUPath"
		If ($RemScope -EQ "All") {
			Add-Content $ErrRepFile "Task Scope -- Un-Link All GPOs From Selected OU"
		}
		Else {
			Add-Content $ErrRepFile "Task Scope -- Un-Link GPO $RemScope From Selected OU"
		}
		Add-Content $ErrRepFile "`nInformation in detail is mentioned below:"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`nTask --- Report About Un-Link GPO From Domain OU"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile $Error
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "==================== End of Error Log ===================="
		$Error.Clear()
	}
}