Param (
	[String]$GPOName,
	[String]$OUPath,
	[String]$ErrRepFile
)

$A = Get-Date

If (Test-Path $ErrRepFile) {
	Remove-Item $ErrRepFile
}

Try {
	Import-Module ActiveDirectory
	Import-Module GroupPolicy
	New-GPLink -Name $GPOName -Target $OUPath -LinkEnabled Yes -Enforced Yes -Order 1
}
Catch {
	[System.Exception]
}
Finally {
	If ($Error) {
		If (Test-Path $ErrRepFile) {
			Remove-Item $ErrRepFile
		}
		New-Item $ErrRepFile -Type File -Force -value "======================= OU MANAGER ERROR LOG ======================="
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "An Error Occurred While OU Manager Attempted To Link GPO To Domain OU"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "OU Manager Report Created On: $A"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "Selected OU -- $OUPath"
		Add-Content $ErrRepFile "GPO To Link -- $GPOName"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`nInformation in detail is mentioned below:"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`nTask --- Link GPO $GPOName To Domain OU"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile $Error
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "==================== End of Error Log ===================="
		$Error.Clear()
	}
}