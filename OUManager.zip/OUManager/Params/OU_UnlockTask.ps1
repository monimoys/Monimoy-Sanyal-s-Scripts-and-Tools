Param (
	[String]$OUPath,
	[String]$ErrRepFile
)
$A = Get-Date
If (Test-Path $ErrRepFile) {
	Remove-Item $ErrRepFile
}

Try {
	Import-Module ActiveDirectory
	Get-ADUser -Filter {(ObjectClass -EQ "User") -AND (ObjectCategory -EQ "User") -AND (SAMAccountName -Like "*")}) -SearchBase $OUPath | Unlock-ADAccount
}
Catch {
	[System.Exception]
}
Finally {
	If ($Error) {
		If (Test-Path $ErrRepFile) {
			Remove-Item $ErrRepFile
		}
		New-Item $ErrRepFile -Type File -Force -value "======================= OU MANAGER ERROR LOG ======================="
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "Selected OU -- $OUPath"
		Add-Content $ErrRepFile "`nTask Executed -- UN-LOCK All Locked-Out User-Accounts Inside Selected OU"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "An Error Occurred While OU Manager Attempted To UN-LOCK All Locked-Out User-Accounts Inside Selected OU"
		Add-Content $ErrRepFile "`nReport Created On $A"
		Add-Content $ErrRepFile "`n"		
		Add-Content $ErrRepFile "`nInformation in detail is mentioned below:"
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile $Error
		Add-Content $ErrRepFile "`n"
		Add-Content $ErrRepFile "==================== End of Error Log ===================="
		$Error.Clear()
	}
}